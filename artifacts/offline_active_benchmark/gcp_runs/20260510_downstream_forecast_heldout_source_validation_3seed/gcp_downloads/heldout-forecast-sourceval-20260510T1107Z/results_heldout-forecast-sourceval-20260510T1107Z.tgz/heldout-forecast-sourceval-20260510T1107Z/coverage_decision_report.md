# Coverage Benchmark Decision Report

## Decision

- downstream training: `hold`
- large training: `hold`
- bounded downstream canary: `hold`
- tiny frozen supervised probe: `pending-audit`
- TS2Vec retraining: `no`
- next CPU gate: `oracle-plus-episode-bootstrap`
- read: keep this in CPU/offline benchmark mode until oracle, confidence, direct-control, and stability gates pass.

## Run Shape

- reports: `3`
- independent final episodes: `12`
- final budget: `4`
- gain records: `180`
- candidate pool size: `36-36 clips, median 36.0`

## Final Leaderboard

| rank | policy | mean final gain | median | CI95 low | CI95 high | episodes | target-used |
|---:|---|---:|---:|---:|---:|---:|---|
| 1 | `submitted_full_replay_v1` | 0.1211 | 0.0513 | 0.0524 | 0.1972 | 12 | N |
| 2 | `window_kcenter_v1` | 0.1127 | 0.0262 | 0.0371 | 0.1921 | 12 | N |
| 3 | `ts2vec_kcenter_v1` | 0.0834 | 0.0318 | 0.0291 | 0.1498 | 12 | N |
| 4 | `quality_stratified_random_v1` | 0.0367 | 0.0125 | 0.0085 | 0.0794 | 12 | N |
| 5 | `quality_only_v1` | 0.0121 | 0.0046 | 0.0042 | 0.0216 | 12 | N |

## Expanded Training Unlock Criteria

- scope: Unlock only a bounded frozen-feature downstream canary; keep TS2Vec retraining and large neural training held.
- focal policy: `ts2vec_kcenter_v1`
- baseline policy: `quality_stratified_random_v1`
- per-pool episodes >= `80`
- candidate clips max >= `72`
- mean delta vs baseline >= `0.0400`
- CI95 low vs baseline >= `0.0250`
- win fraction vs baseline >= `0.7000`
- replay-null p-value <= `0.0100`
- window-kcenter mean delta >= `0.0150` with CI95 low > `0.0000`
- submitted-full replay CI95 low > `0.0000`

## Paired Delta Vs Baseline

| policy | baseline | mean delta | median delta | CI95 low | CI95 high | win frac | paired episodes |
|---|---|---:|---:|---:|---:|---:|---:|
| `submitted_full_replay_v1` | `quality_stratified_random_v1` | 0.0844 | 0.0101 | 0.0119 | 0.1606 | 0.5000 | 12 |
| `window_kcenter_v1` | `quality_stratified_random_v1` | 0.0761 | 0.0025 | 0.0016 | 0.1503 | 0.6667 | 12 |
| `ts2vec_kcenter_v1` | `quality_stratified_random_v1` | 0.0467 | 0.0287 | -0.0365 | 0.1210 | 0.5833 | 12 |
| `quality_only_v1` | `quality_stratified_random_v1` | -0.0246 | 0.0000 | -0.0683 | 0.0001 | 0.1667 | 12 |

## Direct Paired Control Comparisons

| policy | comparator | mean delta | median delta | CI95 low | CI95 high | win frac | loss frac | tie frac | paired episodes |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `submitted_full_replay_v1` | `quality_stratified_random_v1` | 0.0844 | 0.0101 | 0.0166 | 0.1614 | 0.5000 | 0.2500 | 0.2500 | 12 |
| `window_kcenter_v1` | `quality_stratified_random_v1` | 0.0761 | 0.0025 | -0.0010 | 0.1556 | 0.6667 | 0.1667 | 0.1667 | 12 |
| `ts2vec_kcenter_v1` | `quality_only_v1` | 0.0713 | 0.0287 | 0.0111 | 0.1424 | 0.6667 | 0.3333 | 0.0000 | 12 |
| `ts2vec_kcenter_v1` | `quality_stratified_random_v1` | 0.0467 | 0.0287 | -0.0395 | 0.1245 | 0.5833 | 0.3333 | 0.0833 | 12 |
| `ts2vec_kcenter_v1` | `window_kcenter_v1` | -0.0293 | -0.0027 | -0.0963 | 0.0239 | 0.3333 | 0.5000 | 0.1667 | 12 |
| `ts2vec_kcenter_v1` | `submitted_full_replay_v1` | -0.0377 | -0.0071 | -0.1058 | 0.0233 | 0.3333 | 0.5000 | 0.1667 | 12 |

## Deprecated Raw Oracle Capture

- Missing: no oracle policy rows were present in these reports.

## Oracle Diagnostics

- The exact coverage oracle maximizes the exact final-budget coverage objective; smaller budget prefixes are deterministic ordering diagnostics.
- The target-family oracle is a discovery diagnostic, not an exact ceiling for reported coverage gain.
- configured oracle policy: `oracle_exact_coverage_v1`
- exact coverage oracle: `None`
- target-family discovery oracle: `None`
- top deployable policy: `submitted_full_replay_v1`

## Acquisition Stability

- focal policy: `ts2vec_kcenter_v1`
- baseline source: `quality_stratified_random_v1`
- positive seed fraction: `0.6667`
- positive fold fraction: `1.0000`
- min leave-one-seed-out delta: `-0.0057`
- min leave-one-fold-out delta: `0.0311`
- largest single episode contribution fraction: `0.2791`

## Selected Set Audit

| policy | selected | invalid rate | duplicate frac | mean quality | max artifact | unique source groups | top source frac |
|---|---:|---:|---:|---:|---:|---:|---:|
| `quality_only_v1` | 48 | 0.0000 | 0.0000 | 1.0000 | 0.0000 | 12 | 0.2083 |
| `quality_stratified_random_v1` | 48 | 0.0000 | 0.0000 | 1.0000 | 0.0000 | 17 | 0.1042 |
| `submitted_full_replay_v1` | 48 | 0.0000 | 0.0000 | 0.9951 | 0.0085 | 20 | 0.1250 |
| `ts2vec_kcenter_v1` | 48 | 0.0000 | 0.0000 | 0.9934 | 0.0087 | 19 | 0.0833 |
| `window_kcenter_v1` | 48 | 0.0000 | 0.0000 | 0.9921 | 0.0085 | 20 | 0.1250 |

## Budget Curves

| budget | policy | mean gain | episodes |
|---:|---|---:|---:|
| 1 | `window_kcenter_v1` | 0.1108 | 12 |
| 1 | `submitted_full_replay_v1` | 0.0620 | 12 |
| 1 | `quality_stratified_random_v1` | 0.0099 | 12 |
| 1 | `quality_only_v1` | 0.0085 | 12 |
| 1 | `ts2vec_kcenter_v1` | 0.0027 | 12 |
| 2 | `window_kcenter_v1` | 0.1118 | 12 |
| 2 | `submitted_full_replay_v1` | 0.1038 | 12 |
| 2 | `ts2vec_kcenter_v1` | 0.0560 | 12 |
| 2 | `quality_stratified_random_v1` | 0.0338 | 12 |
| 2 | `quality_only_v1` | 0.0085 | 12 |
| 4 | `submitted_full_replay_v1` | 0.1211 | 12 |
| 4 | `window_kcenter_v1` | 0.1127 | 12 |
| 4 | `ts2vec_kcenter_v1` | 0.0834 | 12 |
| 4 | `quality_stratified_random_v1` | 0.0367 | 12 |
| 4 | `quality_only_v1` | 0.0121 | 12 |

## Gates

| gate | status | read |
|---|---|---|
| episode_count | warn | 12 independent final episodes; require at least 20 before downstream spend. |
| large_training_baseline_delta_ci | warn | submitted_full_replay_v1 vs quality_stratified_random_v1 CI low is 0.0119; require > 0.04 before large downstream spend. |
| oracle_present | fail | oracle ceiling is missing. |
| oracle_headroom_sanity | warn | oracle_exact_coverage_v1 headroom median is  with positive fraction ; require positive median and >= 0.70 positive fraction. |
| tiny_probe_random_delta | warn | submitted_full_replay_v1 vs quality_stratified_random_v1: CI low 0.0119, median 0.0101, win fraction 0.5000; tiny-probe threshold is CI low >= 0.02, median >= 0.025, win fraction >= 0.70. |
| tiny_probe_replay_null | warn | submitted_full_replay_v1 replay percentile , +1 p-value , replay-mean CI low . |
| tiny_probe_direct_controls | warn | ts2vec_kcenter_v1 must beat window_kcenter_v1 and submitted_full_replay_v1 by paired mean and median. |
| tiny_probe_stability | warn | ts2vec_kcenter_v1 stability: positive seed fraction 0.6667, positive fold fraction 1.0000, min leave-one-seed -0.0057, min leave-one-fold 0.0311. |
| deployable_top_policy | pass | top non-oracle policy is submitted_full_replay_v1. |

## Notes

- Confidence intervals are episode-level paired bootstraps, not row-level bootstraps.
- Oracle rows are non-deployable ceilings because they inspect the blind target set.
- Gains use primary eval views but still exclude same-feature selector/eval shortcuts.
