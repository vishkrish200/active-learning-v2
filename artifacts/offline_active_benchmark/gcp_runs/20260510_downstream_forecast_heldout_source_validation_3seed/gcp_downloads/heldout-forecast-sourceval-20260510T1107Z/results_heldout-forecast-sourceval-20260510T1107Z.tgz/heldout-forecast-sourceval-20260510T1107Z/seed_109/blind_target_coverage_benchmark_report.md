# Blind Target Coverage Benchmark

## Run

- episodes: `4`
- policies: `quality_stratified_random_v1, quality_only_v1, window_kcenter_v1, submitted_full_replay_v1, ts2vec_kcenter_v1`
- budgets: `1, 2, 4`
- eval views: `ts2vec, window, raw_shape_stats`
- primary eval views: `window, raw_shape_stats`
- distance metric: `euclidean`

## Policy Summary

| policy | mean primary coverage_gain_rel | primary rows | diagnostic rows | underfilled rounds |
|---|---:|---:|---:|---:|
| quality_only_v1 | 0.0005 | 24 | 12 | 0 |
| quality_stratified_random_v1 | 0.0089 | 24 | 12 | 0 |
| submitted_full_replay_v1 | 0.1681 | 12 | 24 | 0 |
| ts2vec_kcenter_v1 | 0.1069 | 24 | 12 | 0 |
| window_kcenter_v1 | 0.1690 | 12 | 24 | 0 |

## Coverage Rows

| episode | budget | policy | eval view | metric | value | primary | feature overlap | target-used |
|---|---:|---|---|---|---:|---|---|---|
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0015 | N | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0036 | N | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0015 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0036 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0690 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0054 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0026 | N | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0063 | N | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0010 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0005 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0690 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0054 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0026 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0063 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0010 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0005 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0021 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0043 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0428 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0195 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0690 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0054 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0047 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0107 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.0428 | N | Y | N |
| episode_000 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0195 | N | Y | N |
| episode_000 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0472 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0048 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 14.9435 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.3361 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.2273 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.3475 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 3.2995 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.3755 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.3889 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 14.9435 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.3361 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.2273 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.3475 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 3.2995 | N | Y | N |
| episode_001 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.3755 | N | Y | N |
| episode_001 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.3889 | N | Y | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0472 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0048 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 14.9435 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.3361 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.2273 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.3475 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 3.2995 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.3755 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.3889 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 13.6020 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.3064 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1674 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.2523 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 2.9245 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.3332 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 14.9435 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.3361 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.2273 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.3475 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 3.2995 | N | Y | N |
| episode_001 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.3755 | N | Y | N |
| episode_001 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.3889 | N | Y | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0472 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0048 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 14.9435 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.3361 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.2273 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.3475 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 3.2995 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.3755 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.3889 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 13.6410 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.3105 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1692 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.2548 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 2.9245 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.3332 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 14.9435 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.3361 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.2273 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.3475 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 3.2995 | N | Y | N |
| episode_001 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.3755 | N | Y | N |
| episode_001 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.3889 | N | Y | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0015 | N | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0036 | N | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0690 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0054 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0026 | N | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0063 | N | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0010 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0005 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0021 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0043 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0428 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0195 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0690 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0054 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0047 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0107 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.0428 | N | Y | N |
| episode_002 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0195 | N | Y | N |
| episode_002 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.3754 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0644 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0095 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0130 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 14.9435 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.3361 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.2273 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.3475 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 3.2995 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.3755 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.3889 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 14.9435 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.3361 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.2273 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.3475 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 3.2995 | N | Y | N |
| episode_003 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.3755 | N | Y | N |
| episode_003 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.3889 | N | Y | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.3754 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0644 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0095 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0130 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 14.9435 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.3361 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.2273 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.3475 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 3.2995 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.3755 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.3889 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 13.6020 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.3064 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1674 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.2523 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 2.9245 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.3332 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 14.9435 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.3361 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.2273 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.3475 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 3.2995 | N | Y | N |
| episode_003 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.3755 | N | Y | N |
| episode_003 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.3889 | N | Y | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.3754 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0644 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0095 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0130 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 14.9435 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.3361 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.2273 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.3475 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 3.2995 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.3755 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.3889 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 13.6410 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.3105 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1692 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.2548 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 2.9245 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.3332 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 14.9435 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.3361 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.2273 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.3475 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 3.2995 | N | Y | N |
| episode_003 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.3755 | N | Y | N |
| episode_003 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.3889 | N | Y | N |

## Hygiene Rows

| episode | budget | policy | metric | value |
|---|---:|---|---|---:|
| episode_000 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_000 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_000 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_000 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_001 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_001 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_001 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_002 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_002 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_002 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_003 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_003 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_003 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |

## Selected Clips

| episode | budget | policy | rank | sample | source | score | quality | artifact | valid |
|---|---:|---|---:|---|---|---:|---:|---:|---|
| episode_000 | 1 | quality_only_v1 | 1 | worker00552_clip020 | worker00552 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | quality_stratified_random_v1 | 1 | worker00585_clip014 | worker00585 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | submitted_full_replay_v1 | 1 | worker00562_clip015 | worker00562 | 0.9487 | 0.975 | 0.005 | Y |
| episode_000 | 1 | ts2vec_kcenter_v1 | 1 | worker00624_clip006 | worker00624 | 0.5443 | 1.000 | 0.000 | Y |
| episode_000 | 1 | window_kcenter_v1 | 1 | worker00562_clip015 | worker00562 | 3.7030 | 0.975 | 0.005 | Y |
| episode_000 | 2 | quality_only_v1 | 1 | worker00552_clip020 | worker00552 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_only_v1 | 2 | worker00557_clip003 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_stratified_random_v1 | 1 | worker00585_clip014 | worker00585 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_stratified_random_v1 | 2 | worker00557_clip003 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | submitted_full_replay_v1 | 1 | worker00562_clip015 | worker00562 | 0.9487 | 0.975 | 0.005 | Y |
| episode_000 | 2 | submitted_full_replay_v1 | 2 | worker00707_clip010 | worker00707 | 0.9267 | 1.000 | 0.000 | Y |
| episode_000 | 2 | ts2vec_kcenter_v1 | 1 | worker00624_clip006 | worker00624 | 0.5443 | 1.000 | 0.000 | Y |
| episode_000 | 2 | ts2vec_kcenter_v1 | 2 | worker00552_clip002 | worker00552 | 0.5021 | 0.956 | 0.009 | Y |
| episode_000 | 2 | window_kcenter_v1 | 1 | worker00562_clip015 | worker00562 | 3.7030 | 0.975 | 0.005 | Y |
| episode_000 | 2 | window_kcenter_v1 | 2 | worker00707_clip010 | worker00707 | 3.2491 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 1 | worker00552_clip020 | worker00552 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 2 | worker00557_clip003 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 3 | worker00557_clip017 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 4 | worker00557_clip020 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 1 | worker00585_clip014 | worker00585 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 2 | worker00557_clip003 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 3 | worker00585_clip005 | worker00585 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 4 | worker00557_clip020 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 1 | worker00562_clip015 | worker00562 | 0.9487 | 0.975 | 0.005 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 2 | worker00707_clip010 | worker00707 | 0.9267 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 3 | worker00562_clip007 | worker00562 | 0.8638 | 0.987 | 0.003 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 4 | worker00624_clip012 | worker00624 | 0.9063 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 1 | worker00624_clip006 | worker00624 | 0.5443 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 2 | worker00552_clip002 | worker00552 | 0.5021 | 0.956 | 0.009 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 3 | worker00562_clip015 | worker00562 | 0.4949 | 0.975 | 0.005 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 4 | worker00707_clip010 | worker00707 | 0.4737 | 1.000 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 1 | worker00562_clip015 | worker00562 | 3.7030 | 0.975 | 0.005 | Y |
| episode_000 | 4 | window_kcenter_v1 | 2 | worker00707_clip010 | worker00707 | 3.2491 | 1.000 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 3 | worker00562_clip007 | worker00562 | 2.1404 | 0.987 | 0.003 | Y |
| episode_000 | 4 | window_kcenter_v1 | 4 | worker00557_clip020 | worker00557 | 1.7325 | 1.000 | 0.000 | Y |
| episode_001 | 1 | quality_only_v1 | 1 | worker00519_clip004 | worker00519 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | quality_stratified_random_v1 | 1 | worker00558_clip009 | worker00558 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | submitted_full_replay_v1 | 1 | worker00643_clip001 | worker00643 | 0.8418 | 1.000 | 0.000 | Y |
| episode_001 | 1 | ts2vec_kcenter_v1 | 1 | worker00880_clip001 | worker00880 | 0.9199 | 1.000 | 0.000 | Y |
| episode_001 | 1 | window_kcenter_v1 | 1 | worker00643_clip001 | worker00643 | 8.3485 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_only_v1 | 1 | worker00519_clip004 | worker00519 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_only_v1 | 2 | worker00529_clip009 | worker00529 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_stratified_random_v1 | 1 | worker00558_clip009 | worker00558 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_stratified_random_v1 | 2 | worker00538_clip011 | worker00538 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | submitted_full_replay_v1 | 1 | worker00643_clip001 | worker00643 | 0.8418 | 1.000 | 0.000 | Y |
| episode_001 | 2 | submitted_full_replay_v1 | 2 | worker00558_clip009 | worker00558 | 0.7765 | 1.000 | 0.000 | Y |
| episode_001 | 2 | ts2vec_kcenter_v1 | 1 | worker00880_clip001 | worker00880 | 0.9199 | 1.000 | 0.000 | Y |
| episode_001 | 2 | ts2vec_kcenter_v1 | 2 | worker00599_clip015 | worker00599 | 0.7042 | 1.000 | 0.000 | Y |
| episode_001 | 2 | window_kcenter_v1 | 1 | worker00643_clip001 | worker00643 | 8.3485 | 1.000 | 0.000 | Y |
| episode_001 | 2 | window_kcenter_v1 | 2 | worker00558_clip009 | worker00558 | 3.8166 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 1 | worker00519_clip004 | worker00519 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 2 | worker00529_clip009 | worker00529 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 3 | worker00538_clip004 | worker00538 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 4 | worker00538_clip011 | worker00538 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 1 | worker00558_clip009 | worker00558 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 2 | worker00538_clip011 | worker00538 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 3 | worker00538_clip004 | worker00538 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 4 | worker00538_clip014 | worker00538 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 1 | worker00643_clip001 | worker00643 | 0.8418 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 2 | worker00558_clip009 | worker00558 | 0.7765 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 3 | worker00880_clip004 | worker00880 | 0.8707 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 4 | worker00519_clip007 | worker00519 | 0.9303 | 0.971 | 0.006 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 1 | worker00880_clip001 | worker00880 | 0.9199 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 2 | worker00599_clip015 | worker00599 | 0.7042 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 3 | worker00558_clip009 | worker00558 | 0.5675 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 4 | worker00627_clip012 | worker00627 | 0.5531 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 1 | worker00643_clip001 | worker00643 | 8.3485 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 2 | worker00558_clip009 | worker00558 | 3.8166 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 3 | worker00519_clip007 | worker00519 | 2.8480 | 0.971 | 0.006 | Y |
| episode_001 | 4 | window_kcenter_v1 | 4 | worker00880_clip004 | worker00880 | 2.2035 | 1.000 | 0.000 | Y |
| episode_002 | 1 | quality_only_v1 | 1 | worker00552_clip020 | worker00552 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | quality_stratified_random_v1 | 1 | worker00585_clip010 | worker00585 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | submitted_full_replay_v1 | 1 | worker00562_clip015 | worker00562 | 0.9487 | 0.975 | 0.005 | Y |
| episode_002 | 1 | ts2vec_kcenter_v1 | 1 | worker00624_clip006 | worker00624 | 0.5443 | 1.000 | 0.000 | Y |
| episode_002 | 1 | window_kcenter_v1 | 1 | worker00562_clip015 | worker00562 | 3.7030 | 0.975 | 0.005 | Y |
| episode_002 | 2 | quality_only_v1 | 1 | worker00552_clip020 | worker00552 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_only_v1 | 2 | worker00557_clip003 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_stratified_random_v1 | 1 | worker00585_clip010 | worker00585 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_stratified_random_v1 | 2 | worker00557_clip017 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | submitted_full_replay_v1 | 1 | worker00562_clip015 | worker00562 | 0.9487 | 0.975 | 0.005 | Y |
| episode_002 | 2 | submitted_full_replay_v1 | 2 | worker00707_clip010 | worker00707 | 0.9267 | 1.000 | 0.000 | Y |
| episode_002 | 2 | ts2vec_kcenter_v1 | 1 | worker00624_clip006 | worker00624 | 0.5443 | 1.000 | 0.000 | Y |
| episode_002 | 2 | ts2vec_kcenter_v1 | 2 | worker00552_clip002 | worker00552 | 0.5021 | 0.956 | 0.009 | Y |
| episode_002 | 2 | window_kcenter_v1 | 1 | worker00562_clip015 | worker00562 | 3.7030 | 0.975 | 0.005 | Y |
| episode_002 | 2 | window_kcenter_v1 | 2 | worker00707_clip010 | worker00707 | 3.2491 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 1 | worker00552_clip020 | worker00552 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 2 | worker00557_clip003 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 3 | worker00557_clip017 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 4 | worker00557_clip020 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 1 | worker00585_clip010 | worker00585 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 2 | worker00557_clip017 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 3 | worker00585_clip005 | worker00585 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 4 | worker00585_clip014 | worker00585 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 1 | worker00562_clip015 | worker00562 | 0.9487 | 0.975 | 0.005 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 2 | worker00707_clip010 | worker00707 | 0.9267 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 3 | worker00562_clip007 | worker00562 | 0.8638 | 0.987 | 0.003 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 4 | worker00624_clip012 | worker00624 | 0.9063 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 1 | worker00624_clip006 | worker00624 | 0.5443 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 2 | worker00552_clip002 | worker00552 | 0.5021 | 0.956 | 0.009 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 3 | worker00562_clip015 | worker00562 | 0.4949 | 0.975 | 0.005 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 4 | worker00707_clip010 | worker00707 | 0.4737 | 1.000 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 1 | worker00562_clip015 | worker00562 | 3.7030 | 0.975 | 0.005 | Y |
| episode_002 | 4 | window_kcenter_v1 | 2 | worker00707_clip010 | worker00707 | 3.2491 | 1.000 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 3 | worker00562_clip007 | worker00562 | 2.1404 | 0.987 | 0.003 | Y |
| episode_002 | 4 | window_kcenter_v1 | 4 | worker00557_clip020 | worker00557 | 1.7325 | 1.000 | 0.000 | Y |
| episode_003 | 1 | quality_only_v1 | 1 | worker00519_clip004 | worker00519 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | quality_stratified_random_v1 | 1 | worker00552_clip020 | worker00552 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | submitted_full_replay_v1 | 1 | worker00643_clip001 | worker00643 | 0.8418 | 1.000 | 0.000 | Y |
| episode_003 | 1 | ts2vec_kcenter_v1 | 1 | worker00880_clip001 | worker00880 | 0.9199 | 1.000 | 0.000 | Y |
| episode_003 | 1 | window_kcenter_v1 | 1 | worker00643_clip001 | worker00643 | 8.3485 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_only_v1 | 1 | worker00519_clip004 | worker00519 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_only_v1 | 2 | worker00529_clip009 | worker00529 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_stratified_random_v1 | 1 | worker00552_clip020 | worker00552 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_stratified_random_v1 | 2 | worker00538_clip014 | worker00538 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | submitted_full_replay_v1 | 1 | worker00643_clip001 | worker00643 | 0.8418 | 1.000 | 0.000 | Y |
| episode_003 | 2 | submitted_full_replay_v1 | 2 | worker00558_clip009 | worker00558 | 0.7765 | 1.000 | 0.000 | Y |
| episode_003 | 2 | ts2vec_kcenter_v1 | 1 | worker00880_clip001 | worker00880 | 0.9199 | 1.000 | 0.000 | Y |
| episode_003 | 2 | ts2vec_kcenter_v1 | 2 | worker00599_clip015 | worker00599 | 0.7042 | 1.000 | 0.000 | Y |
| episode_003 | 2 | window_kcenter_v1 | 1 | worker00643_clip001 | worker00643 | 8.3485 | 1.000 | 0.000 | Y |
| episode_003 | 2 | window_kcenter_v1 | 2 | worker00558_clip009 | worker00558 | 3.8166 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 1 | worker00519_clip004 | worker00519 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 2 | worker00529_clip009 | worker00529 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 3 | worker00538_clip004 | worker00538 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 4 | worker00538_clip011 | worker00538 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 1 | worker00552_clip020 | worker00552 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 2 | worker00538_clip014 | worker00538 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 3 | worker00558_clip014 | worker00558 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 4 | worker00538_clip011 | worker00538 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 1 | worker00643_clip001 | worker00643 | 0.8418 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 2 | worker00558_clip009 | worker00558 | 0.7765 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 3 | worker00880_clip004 | worker00880 | 0.8707 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 4 | worker00519_clip007 | worker00519 | 0.9303 | 0.971 | 0.006 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 1 | worker00880_clip001 | worker00880 | 0.9199 | 1.000 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 2 | worker00599_clip015 | worker00599 | 0.7042 | 1.000 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 3 | worker00558_clip009 | worker00558 | 0.5675 | 1.000 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 4 | worker00627_clip012 | worker00627 | 0.5531 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 1 | worker00643_clip001 | worker00643 | 8.3485 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 2 | worker00558_clip009 | worker00558 | 3.8166 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 3 | worker00519_clip007 | worker00519 | 2.8480 | 0.971 | 0.006 | Y |
| episode_003 | 4 | window_kcenter_v1 | 4 | worker00880_clip004 | worker00880 | 2.2035 | 1.000 | 0.000 | Y |

## Decision Notes

- Primary rows exclude same-feature-family selector/eval comparisons.
- Oracle rows, when present, are diagnostics because they inspect the target set.
- Deployable v1 policies only select candidates that pass quality and artifact gates.
