# Downstream Forecast Task

Actual Downstream Model Update: selected raw IMU clips are added to support, a ridge autoregressive forecaster is retrained, and held-out target forecast MSE is measured.

## Decision

- downstream task: `raw_imu_autoregressive_forecast`
- model update: `actual_retrain_after_acquisition`
- large training: `hold_until_repeated_real_task_runs`
- top policy: `window_kcenter_v1`
- baseline policy: `quality_stratified_random_v1`
- after-MSE delta vs baseline: `0.001920`
- relative reduction delta vs baseline: `0.003088`
- read: Actual downstream model-update task: raw IMU autoregressive forecaster is retrained after acquisition; this is not a source-family pseudo-label proxy.

## Final Means

| policy | after MSE | relative reduction | rows |
|---|---:|---:|---:|
| `ts2vec_kcenter_v1` | 0.435887 | 0.005273 | 4 |
| `submitted_full_replay_v1` | 0.436370 | 0.003933 | 4 |
| `window_kcenter_v1` | 0.436618 | 0.003618 | 4 |
| `quality_stratified_random_v1` | 0.438538 | 0.000530 | 4 |
| `quality_only_v1` | 0.438725 | -0.000237 | 4 |

## Budget Means

| policy | budget | after MSE | relative reduction | rows |
|---|---:|---:|---:|---:|
| `quality_only_v1` | 0 | 0.438463 | 0.000000 | 4 |
| `quality_only_v1` | 1 | 0.438436 | 0.000209 | 4 |
| `quality_only_v1` | 2 | 0.438557 | -0.000002 | 4 |
| `quality_only_v1` | 4 | 0.438725 | -0.000237 | 4 |
| `quality_stratified_random_v1` | 0 | 0.438463 | 0.000000 | 4 |
| `quality_stratified_random_v1` | 1 | 0.438400 | 0.000704 | 4 |
| `quality_stratified_random_v1` | 2 | 0.438458 | 0.000607 | 4 |
| `quality_stratified_random_v1` | 4 | 0.438538 | 0.000530 | 4 |
| `submitted_full_replay_v1` | 0 | 0.438463 | 0.000000 | 4 |
| `submitted_full_replay_v1` | 1 | 0.435832 | 0.003919 | 4 |
| `submitted_full_replay_v1` | 2 | 0.435984 | 0.004667 | 4 |
| `submitted_full_replay_v1` | 4 | 0.436370 | 0.003933 | 4 |
| `ts2vec_kcenter_v1` | 0 | 0.438463 | 0.000000 | 4 |
| `ts2vec_kcenter_v1` | 1 | 0.438305 | 0.000173 | 4 |
| `ts2vec_kcenter_v1` | 2 | 0.438327 | 0.001116 | 4 |
| `ts2vec_kcenter_v1` | 4 | 0.435887 | 0.005273 | 4 |
| `window_kcenter_v1` | 0 | 0.438463 | 0.000000 | 4 |
| `window_kcenter_v1` | 1 | 0.435832 | 0.003919 | 4 |
| `window_kcenter_v1` | 2 | 0.435984 | 0.004667 | 4 |
| `window_kcenter_v1` | 4 | 0.436618 | 0.003618 | 4 |

## Caveat

- This is a real model update task, but it is still a small linear forecaster, not final challenge-label training.
- Budget `0` is the support-only model. Later budgets retrain after adding selected candidate clips.
