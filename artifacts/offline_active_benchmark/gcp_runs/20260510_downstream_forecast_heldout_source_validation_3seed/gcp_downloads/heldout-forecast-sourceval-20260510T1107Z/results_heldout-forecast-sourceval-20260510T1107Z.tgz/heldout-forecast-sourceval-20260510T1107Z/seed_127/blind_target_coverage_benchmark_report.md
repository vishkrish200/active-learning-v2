# Blind Target Coverage Benchmark

## Run

- episodes: `4`
- policies: `quality_stratified_random_v1, quality_only_v1, window_kcenter_v1, submitted_full_replay_v1, ts2vec_kcenter_v1`
- budgets: `1, 2, 4`
- eval views: `ts2vec, window, raw_shape_stats`
- primary eval views: `window, raw_shape_stats`
- distance metric: `euclidean`

## Policy Summary

| policy | mean primary coverage_gain_rel | primary rows | diagnostic rows | underfilled rounds |
|---|---:|---:|---:|---:|
| quality_only_v1 | 0.0254 | 24 | 12 | 0 |
| quality_stratified_random_v1 | 0.0263 | 24 | 12 | 0 |
| submitted_full_replay_v1 | 0.0290 | 12 | 24 | 0 |
| ts2vec_kcenter_v1 | 0.0192 | 24 | 12 | 0 |
| window_kcenter_v1 | 0.0235 | 12 | 24 | 0 |

## Coverage Rows

| episode | budget | policy | eval view | metric | value | primary | feature overlap | target-used |
|---|---:|---|---|---|---:|---|---|---|
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.9843 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0237 | N | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0325 | N | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_000 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.3318 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 1.9836 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0237 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0324 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.3311 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0445 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 1.5929 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0358 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0227 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0311 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.3227 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0433 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.0882 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0470 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0222 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0305 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.3449 | N | Y | N |
| episode_000 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0463 | N | Y | N |
| episode_000 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.9843 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0237 | N | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0325 | N | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_000 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.3318 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 1.9836 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0237 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0324 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.3311 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0445 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 1.5929 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0358 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0227 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0311 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.3227 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0433 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.0882 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0470 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0222 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0305 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.3449 | N | Y | N |
| episode_000 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0463 | N | Y | N |
| episode_000 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.9843 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0237 | N | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0325 | N | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_000 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.3318 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 2.0882 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0470 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0237 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0324 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.3449 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0463 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 1.5929 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0358 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0227 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0311 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.3227 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0433 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.1224 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1118 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0574 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1143 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.3200 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1181 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.0882 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0470 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0222 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0305 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.3449 | N | Y | N |
| episode_000 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0463 | N | Y | N |
| episode_000 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0166 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0473 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0271 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0700 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0837 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0372 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0106 | N | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0227 | N | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0837 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0372 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0271 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0700 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0837 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0372 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 1.2256 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0667 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0531 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0912 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.4289 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1192 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.9843 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0237 | N | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0325 | N | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_002 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.3318 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 1.5929 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0358 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0227 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0311 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.3227 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0433 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 1.5929 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0358 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0227 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0311 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.3227 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0433 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.0882 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0470 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0222 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0305 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.3449 | N | Y | N |
| episode_002 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0463 | N | Y | N |
| episode_002 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.9843 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0237 | N | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0325 | N | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_002 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.3318 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 1.5929 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0358 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0227 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0311 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.3227 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0433 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 1.5929 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0358 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0227 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0311 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.3227 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0433 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.0882 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0470 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0222 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0305 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.3449 | N | Y | N |
| episode_002 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0463 | N | Y | N |
| episode_002 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.9843 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0237 | N | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0325 | N | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_002 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.3318 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 1.9836 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0446 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0237 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0324 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.3311 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0445 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 1.5929 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0358 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0227 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0311 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.3227 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0433 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.1224 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1118 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0574 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1143 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.3200 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1181 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.0882 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0470 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0222 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0305 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.3449 | N | Y | N |
| episode_002 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0463 | N | Y | N |
| episode_002 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0166 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0473 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0106 | N | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0227 | N | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0837 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0372 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0271 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0700 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0837 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0372 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 1.2256 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0667 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0531 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0912 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.4289 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1192 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |

## Hygiene Rows

| episode | budget | policy | metric | value |
|---|---:|---|---|---:|
| episode_000 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_000 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_000 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_000 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_001 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_001 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_001 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_002 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_002 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_002 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_003 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_003 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_003 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |

## Selected Clips

| episode | budget | policy | rank | sample | source | score | quality | artifact | valid |
|---|---:|---|---:|---|---|---:|---:|---:|---|
| episode_000 | 1 | quality_only_v1 | 1 | worker00577_clip004 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | quality_stratified_random_v1 | 1 | worker00577_clip020 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | submitted_full_replay_v1 | 1 | worker00602_clip011 | worker00602 | 0.8677 | 1.000 | 0.000 | Y |
| episode_000 | 1 | ts2vec_kcenter_v1 | 1 | worker00579_clip009 | worker00579 | 0.7520 | 0.998 | 0.000 | Y |
| episode_000 | 1 | window_kcenter_v1 | 1 | worker00602_clip012 | worker00602 | 8.3656 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_only_v1 | 1 | worker00577_clip004 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_only_v1 | 2 | worker00577_clip009 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_stratified_random_v1 | 1 | worker00577_clip020 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_stratified_random_v1 | 2 | worker00579_clip007 | worker00579 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | submitted_full_replay_v1 | 1 | worker00602_clip011 | worker00602 | 0.8677 | 1.000 | 0.000 | Y |
| episode_000 | 2 | submitted_full_replay_v1 | 2 | worker00579_clip009 | worker00579 | 0.8848 | 0.998 | 0.000 | Y |
| episode_000 | 2 | ts2vec_kcenter_v1 | 1 | worker00579_clip009 | worker00579 | 0.7520 | 0.998 | 0.000 | Y |
| episode_000 | 2 | ts2vec_kcenter_v1 | 2 | worker00603_clip005 | worker00603 | 0.6624 | 0.996 | 0.001 | Y |
| episode_000 | 2 | window_kcenter_v1 | 1 | worker00602_clip012 | worker00602 | 8.3656 | 1.000 | 0.000 | Y |
| episode_000 | 2 | window_kcenter_v1 | 2 | worker00599_clip004 | worker00599 | 3.3422 | 0.943 | 0.001 | Y |
| episode_000 | 4 | quality_only_v1 | 1 | worker00577_clip004 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 2 | worker00577_clip009 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 3 | worker00577_clip020 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 4 | worker00579_clip007 | worker00579 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 1 | worker00577_clip020 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 2 | worker00579_clip007 | worker00579 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 3 | worker00599_clip017 | worker00599 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 4 | worker00602_clip012 | worker00602 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 1 | worker00602_clip011 | worker00602 | 0.8677 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 2 | worker00579_clip009 | worker00579 | 0.8848 | 0.998 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 3 | worker00599_clip017 | worker00599 | 0.7919 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 4 | worker00785_clip020 | worker00785 | 0.9020 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 1 | worker00579_clip009 | worker00579 | 0.7520 | 0.998 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 2 | worker00603_clip005 | worker00603 | 0.6624 | 0.996 | 0.001 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 3 | worker00599_clip017 | worker00599 | 0.6122 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 4 | worker00707_clip003 | worker00707 | 0.5816 | 0.977 | 0.005 | Y |
| episode_000 | 4 | window_kcenter_v1 | 1 | worker00602_clip012 | worker00602 | 8.3656 | 1.000 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 2 | worker00599_clip004 | worker00599 | 3.3422 | 0.943 | 0.001 | Y |
| episode_000 | 4 | window_kcenter_v1 | 3 | worker00785_clip020 | worker00785 | 2.8892 | 1.000 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 4 | worker00579_clip009 | worker00579 | 2.8155 | 0.998 | 0.000 | Y |
| episode_001 | 1 | quality_only_v1 | 1 | worker00516_clip005 | worker00516 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | quality_stratified_random_v1 | 1 | worker00602_clip012 | worker00602 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | submitted_full_replay_v1 | 1 | worker00769_clip002 | worker00769 | 0.9700 | 1.000 | 0.000 | Y |
| episode_001 | 1 | ts2vec_kcenter_v1 | 1 | worker00769_clip017 | worker00769 | 0.7068 | 1.000 | 0.000 | Y |
| episode_001 | 1 | window_kcenter_v1 | 1 | worker00713_clip016 | worker00713 | 5.7859 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_only_v1 | 1 | worker00516_clip005 | worker00516 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_only_v1 | 2 | worker00516_clip016 | worker00516 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_stratified_random_v1 | 1 | worker00602_clip012 | worker00602 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_stratified_random_v1 | 2 | worker00518_clip001 | worker00518 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | submitted_full_replay_v1 | 1 | worker00769_clip002 | worker00769 | 0.9700 | 1.000 | 0.000 | Y |
| episode_001 | 2 | submitted_full_replay_v1 | 2 | worker00617_clip004 | worker00617 | 0.8958 | 1.000 | 0.000 | Y |
| episode_001 | 2 | ts2vec_kcenter_v1 | 1 | worker00769_clip017 | worker00769 | 0.7068 | 1.000 | 0.000 | Y |
| episode_001 | 2 | ts2vec_kcenter_v1 | 2 | worker00516_clip016 | worker00516 | 0.7040 | 1.000 | 0.000 | Y |
| episode_001 | 2 | window_kcenter_v1 | 1 | worker00713_clip016 | worker00713 | 5.7859 | 1.000 | 0.000 | Y |
| episode_001 | 2 | window_kcenter_v1 | 2 | worker00769_clip002 | worker00769 | 5.5840 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 1 | worker00516_clip005 | worker00516 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 2 | worker00516_clip016 | worker00516 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 3 | worker00518_clip001 | worker00518 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 4 | worker00518_clip009 | worker00518 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 1 | worker00602_clip012 | worker00602 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 2 | worker00518_clip001 | worker00518 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 3 | worker00602_clip011 | worker00602 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 4 | worker00516_clip005 | worker00516 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 1 | worker00769_clip002 | worker00769 | 0.9700 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 2 | worker00617_clip004 | worker00617 | 0.8958 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 3 | worker00713_clip016 | worker00713 | 0.7453 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 4 | worker00666_clip016 | worker00666 | 0.7764 | 0.996 | 0.001 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 1 | worker00769_clip017 | worker00769 | 0.7068 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 2 | worker00516_clip016 | worker00516 | 0.7040 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 3 | worker00769_clip002 | worker00769 | 0.6936 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 4 | worker00617_clip004 | worker00617 | 0.6703 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 1 | worker00713_clip016 | worker00713 | 5.7859 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 2 | worker00769_clip002 | worker00769 | 5.5840 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 3 | worker00617_clip004 | worker00617 | 5.0025 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 4 | worker00652_clip007 | worker00652 | 4.2884 | 1.000 | 0.000 | Y |
| episode_002 | 1 | quality_only_v1 | 1 | worker00577_clip004 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | quality_stratified_random_v1 | 1 | worker00602_clip011 | worker00602 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | submitted_full_replay_v1 | 1 | worker00602_clip011 | worker00602 | 0.8677 | 1.000 | 0.000 | Y |
| episode_002 | 1 | ts2vec_kcenter_v1 | 1 | worker00579_clip009 | worker00579 | 0.7520 | 0.998 | 0.000 | Y |
| episode_002 | 1 | window_kcenter_v1 | 1 | worker00602_clip012 | worker00602 | 8.3656 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_only_v1 | 1 | worker00577_clip004 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_only_v1 | 2 | worker00577_clip009 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_stratified_random_v1 | 1 | worker00602_clip011 | worker00602 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_stratified_random_v1 | 2 | worker00579_clip007 | worker00579 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | submitted_full_replay_v1 | 1 | worker00602_clip011 | worker00602 | 0.8677 | 1.000 | 0.000 | Y |
| episode_002 | 2 | submitted_full_replay_v1 | 2 | worker00579_clip009 | worker00579 | 0.8848 | 0.998 | 0.000 | Y |
| episode_002 | 2 | ts2vec_kcenter_v1 | 1 | worker00579_clip009 | worker00579 | 0.7520 | 0.998 | 0.000 | Y |
| episode_002 | 2 | ts2vec_kcenter_v1 | 2 | worker00603_clip005 | worker00603 | 0.6624 | 0.996 | 0.001 | Y |
| episode_002 | 2 | window_kcenter_v1 | 1 | worker00602_clip012 | worker00602 | 8.3656 | 1.000 | 0.000 | Y |
| episode_002 | 2 | window_kcenter_v1 | 2 | worker00599_clip004 | worker00599 | 3.3422 | 0.943 | 0.001 | Y |
| episode_002 | 4 | quality_only_v1 | 1 | worker00577_clip004 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 2 | worker00577_clip009 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 3 | worker00577_clip020 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 4 | worker00579_clip007 | worker00579 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 1 | worker00602_clip011 | worker00602 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 2 | worker00579_clip007 | worker00579 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 3 | worker00599_clip012 | worker00599 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 4 | worker00577_clip020 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 1 | worker00602_clip011 | worker00602 | 0.8677 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 2 | worker00579_clip009 | worker00579 | 0.8848 | 0.998 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 3 | worker00599_clip017 | worker00599 | 0.7919 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 4 | worker00785_clip020 | worker00785 | 0.9020 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 1 | worker00579_clip009 | worker00579 | 0.7520 | 0.998 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 2 | worker00603_clip005 | worker00603 | 0.6624 | 0.996 | 0.001 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 3 | worker00599_clip017 | worker00599 | 0.6122 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 4 | worker00707_clip003 | worker00707 | 0.5816 | 0.977 | 0.005 | Y |
| episode_002 | 4 | window_kcenter_v1 | 1 | worker00602_clip012 | worker00602 | 8.3656 | 1.000 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 2 | worker00599_clip004 | worker00599 | 3.3422 | 0.943 | 0.001 | Y |
| episode_002 | 4 | window_kcenter_v1 | 3 | worker00785_clip020 | worker00785 | 2.8892 | 1.000 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 4 | worker00579_clip009 | worker00579 | 2.8155 | 0.998 | 0.000 | Y |
| episode_003 | 1 | quality_only_v1 | 1 | worker00516_clip005 | worker00516 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | quality_stratified_random_v1 | 1 | worker00518_clip009 | worker00518 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | submitted_full_replay_v1 | 1 | worker00769_clip002 | worker00769 | 0.9700 | 1.000 | 0.000 | Y |
| episode_003 | 1 | ts2vec_kcenter_v1 | 1 | worker00769_clip017 | worker00769 | 0.7068 | 1.000 | 0.000 | Y |
| episode_003 | 1 | window_kcenter_v1 | 1 | worker00713_clip016 | worker00713 | 5.7859 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_only_v1 | 1 | worker00516_clip005 | worker00516 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_only_v1 | 2 | worker00516_clip016 | worker00516 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_stratified_random_v1 | 1 | worker00518_clip009 | worker00518 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_stratified_random_v1 | 2 | worker00602_clip012 | worker00602 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | submitted_full_replay_v1 | 1 | worker00769_clip002 | worker00769 | 0.9700 | 1.000 | 0.000 | Y |
| episode_003 | 2 | submitted_full_replay_v1 | 2 | worker00617_clip004 | worker00617 | 0.8958 | 1.000 | 0.000 | Y |
| episode_003 | 2 | ts2vec_kcenter_v1 | 1 | worker00769_clip017 | worker00769 | 0.7068 | 1.000 | 0.000 | Y |
| episode_003 | 2 | ts2vec_kcenter_v1 | 2 | worker00516_clip016 | worker00516 | 0.7040 | 1.000 | 0.000 | Y |
| episode_003 | 2 | window_kcenter_v1 | 1 | worker00713_clip016 | worker00713 | 5.7859 | 1.000 | 0.000 | Y |
| episode_003 | 2 | window_kcenter_v1 | 2 | worker00769_clip002 | worker00769 | 5.5840 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 1 | worker00516_clip005 | worker00516 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 2 | worker00516_clip016 | worker00516 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 3 | worker00518_clip001 | worker00518 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 4 | worker00518_clip009 | worker00518 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 1 | worker00518_clip009 | worker00518 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 2 | worker00602_clip012 | worker00602 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 3 | worker00518_clip001 | worker00518 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 4 | worker00518_clip015 | worker00518 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 1 | worker00769_clip002 | worker00769 | 0.9700 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 2 | worker00617_clip004 | worker00617 | 0.8958 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 3 | worker00713_clip016 | worker00713 | 0.7453 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 4 | worker00666_clip016 | worker00666 | 0.7764 | 0.996 | 0.001 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 1 | worker00769_clip017 | worker00769 | 0.7068 | 1.000 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 2 | worker00516_clip016 | worker00516 | 0.7040 | 1.000 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 3 | worker00769_clip002 | worker00769 | 0.6936 | 1.000 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 4 | worker00617_clip004 | worker00617 | 0.6703 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 1 | worker00713_clip016 | worker00713 | 5.7859 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 2 | worker00769_clip002 | worker00769 | 5.5840 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 3 | worker00617_clip004 | worker00617 | 5.0025 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 4 | worker00652_clip007 | worker00652 | 4.2884 | 1.000 | 0.000 | Y |

## Decision Notes

- Primary rows exclude same-feature-family selector/eval comparisons.
- Oracle rows, when present, are diagnostics because they inspect the target set.
- Deployable v1 policies only select candidates that pass quality and artifact gates.
