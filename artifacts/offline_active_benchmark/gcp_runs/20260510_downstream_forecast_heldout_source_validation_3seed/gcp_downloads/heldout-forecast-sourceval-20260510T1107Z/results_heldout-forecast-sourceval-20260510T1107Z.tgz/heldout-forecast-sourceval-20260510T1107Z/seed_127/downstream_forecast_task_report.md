# Downstream Forecast Task

Actual Downstream Model Update: selected raw IMU clips are added to support, a ridge autoregressive forecaster is retrained, and held-out target forecast MSE is measured.

## Decision

- downstream task: `raw_imu_autoregressive_forecast`
- model update: `actual_retrain_after_acquisition`
- large training: `hold_until_repeated_real_task_runs`
- top policy: `window_kcenter_v1`
- baseline policy: `quality_stratified_random_v1`
- after-MSE delta vs baseline: `-0.000456`
- relative reduction delta vs baseline: `-0.001870`
- read: Actual downstream model-update task: raw IMU autoregressive forecaster is retrained after acquisition; this is not a source-family pseudo-label proxy.

## Final Means

| policy | after MSE | relative reduction | rows |
|---|---:|---:|---:|
| `quality_only_v1` | 0.127946 | -0.000928 | 4 |
| `quality_stratified_random_v1` | 0.128229 | -0.002289 | 4 |
| `submitted_full_replay_v1` | 0.128401 | -0.002621 | 4 |
| `ts2vec_kcenter_v1` | 0.128435 | -0.002584 | 4 |
| `window_kcenter_v1` | 0.128685 | -0.004159 | 4 |

## Budget Means

| policy | budget | after MSE | relative reduction | rows |
|---|---:|---:|---:|---:|
| `quality_only_v1` | 0 | 0.127721 | 0.000000 | 4 |
| `quality_only_v1` | 1 | 0.127738 | -0.000044 | 4 |
| `quality_only_v1` | 2 | 0.127749 | -0.000072 | 4 |
| `quality_only_v1` | 4 | 0.127946 | -0.000928 | 4 |
| `quality_stratified_random_v1` | 0 | 0.127721 | 0.000000 | 4 |
| `quality_stratified_random_v1` | 1 | 0.127714 | 0.000113 | 4 |
| `quality_stratified_random_v1` | 2 | 0.127811 | -0.000254 | 4 |
| `quality_stratified_random_v1` | 4 | 0.128229 | -0.002289 | 4 |
| `submitted_full_replay_v1` | 0 | 0.127721 | 0.000000 | 4 |
| `submitted_full_replay_v1` | 1 | 0.128486 | -0.003624 | 4 |
| `submitted_full_replay_v1` | 2 | 0.128439 | -0.002859 | 4 |
| `submitted_full_replay_v1` | 4 | 0.128401 | -0.002621 | 4 |
| `ts2vec_kcenter_v1` | 0 | 0.127721 | 0.000000 | 4 |
| `ts2vec_kcenter_v1` | 1 | 0.127684 | 0.000721 | 4 |
| `ts2vec_kcenter_v1` | 2 | 0.127697 | 0.000631 | 4 |
| `ts2vec_kcenter_v1` | 4 | 0.128435 | -0.002584 | 4 |
| `window_kcenter_v1` | 0 | 0.127721 | 0.000000 | 4 |
| `window_kcenter_v1` | 1 | 0.127713 | 0.000082 | 4 |
| `window_kcenter_v1` | 2 | 0.128491 | -0.003791 | 4 |
| `window_kcenter_v1` | 4 | 0.128685 | -0.004159 | 4 |

## Caveat

- This is a real model update task, but it is still a small linear forecaster, not final challenge-label training.
- Budget `0` is the support-only model. Later budgets retrain after adding selected candidate clips.
