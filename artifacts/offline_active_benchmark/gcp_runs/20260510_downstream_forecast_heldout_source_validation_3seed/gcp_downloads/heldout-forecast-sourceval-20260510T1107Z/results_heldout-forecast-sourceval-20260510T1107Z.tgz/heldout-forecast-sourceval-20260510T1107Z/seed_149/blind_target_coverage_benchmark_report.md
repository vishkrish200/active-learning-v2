# Blind Target Coverage Benchmark

## Run

- episodes: `4`
- policies: `quality_stratified_random_v1, quality_only_v1, window_kcenter_v1, submitted_full_replay_v1, ts2vec_kcenter_v1`
- budgets: `1, 2, 4`
- eval views: `ts2vec, window, raw_shape_stats`
- primary eval views: `window, raw_shape_stats`
- distance metric: `euclidean`

## Policy Summary

| policy | mean primary coverage_gain_rel | primary rows | diagnostic rows | underfilled rounds |
|---|---:|---:|---:|---:|
| quality_only_v1 | 0.0032 | 24 | 12 | 0 |
| quality_stratified_random_v1 | 0.0452 | 24 | 12 | 0 |
| submitted_full_replay_v1 | 0.0898 | 12 | 24 | 0 |
| ts2vec_kcenter_v1 | 0.0160 | 24 | 12 | 0 |
| window_kcenter_v1 | 0.1430 | 12 | 24 | 0 |

## Coverage Rows

| episode | budget | policy | eval view | metric | value | primary | feature overlap | target-used |
|---|---:|---|---|---|---:|---|---|---|
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0028 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0056 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0536 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1177 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.1546 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0950 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.1325 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0126 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.1022 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0324 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.1022 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0324 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 5.0694 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2819 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.5000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1515 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.3180 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.7667 | N | Y | N |
| episode_001 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.2537 | N | Y | N |
| episode_001 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.1325 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0126 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 5.0694 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.2819 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.5000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.1515 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.3180 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.7667 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.2537 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.4444 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 4.4994 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2507 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.5000 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0523 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.1094 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.1287 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0404 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.1022 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0324 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 5.1763 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2880 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.5000 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1515 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.3180 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.7667 | N | Y | N |
| episode_001 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.2537 | N | Y | N |
| episode_001 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.1325 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0126 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 5.0694 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.2819 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.5000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.1515 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.3180 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.7667 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.2537 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.4444 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 5.1763 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2880 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.5000 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.1515 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.3180 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.7667 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.2537 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.1022 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0324 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 5.1763 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2880 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.5000 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1535 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.3234 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.8095 | N | Y | N |
| episode_001 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.2715 | N | Y | N |
| episode_001 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0028 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0056 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0536 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1177 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.1546 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0950 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.1325 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0126 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.1022 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0324 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.1022 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0324 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 5.0694 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2819 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.5000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1515 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.3180 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.7667 | N | Y | N |
| episode_003 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.2537 | N | Y | N |
| episode_003 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.1325 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0126 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 4.4994 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2507 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.5000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0523 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.1094 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.1287 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0404 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.1022 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0324 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 5.1763 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2880 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.5000 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1515 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.3180 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.7667 | N | Y | N |
| episode_003 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.2537 | N | Y | N |
| episode_003 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.1325 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0126 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.1325 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0126 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 5.1763 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2880 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.5000 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.1515 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.3180 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.7667 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.2537 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.1022 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0324 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 5.1763 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2880 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.5000 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1535 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.3234 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.8095 | N | Y | N |
| episode_003 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.2715 | N | Y | N |
| episode_003 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.4444 | N | Y | N |

## Hygiene Rows

| episode | budget | policy | metric | value |
|---|---:|---|---|---:|
| episode_000 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_000 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_000 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_000 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_001 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_001 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_001 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_002 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_002 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_002 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_003 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_003 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_003 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |

## Selected Clips

| episode | budget | policy | rank | sample | source | score | quality | artifact | valid |
|---|---:|---|---:|---|---|---:|---:|---:|---|
| episode_000 | 1 | quality_only_v1 | 1 | worker00512_clip001 | worker00512 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | quality_stratified_random_v1 | 1 | worker00523_clip017 | worker00523 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | submitted_full_replay_v1 | 1 | worker00609_clip019 | worker00609 | 0.9866 | 1.000 | 0.000 | Y |
| episode_000 | 1 | ts2vec_kcenter_v1 | 1 | worker00609_clip019 | worker00609 | 0.6330 | 1.000 | 0.000 | Y |
| episode_000 | 1 | window_kcenter_v1 | 1 | worker00609_clip004 | worker00609 | 3.8874 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_only_v1 | 1 | worker00512_clip001 | worker00512 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_only_v1 | 2 | worker00523_clip003 | worker00523 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_stratified_random_v1 | 1 | worker00523_clip017 | worker00523 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_stratified_random_v1 | 2 | worker00577_clip001 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | submitted_full_replay_v1 | 1 | worker00609_clip019 | worker00609 | 0.9866 | 1.000 | 0.000 | Y |
| episode_000 | 2 | submitted_full_replay_v1 | 2 | worker00846_clip003 | worker00846 | 0.8445 | 1.000 | 0.000 | Y |
| episode_000 | 2 | ts2vec_kcenter_v1 | 1 | worker00609_clip019 | worker00609 | 0.6330 | 1.000 | 0.000 | Y |
| episode_000 | 2 | ts2vec_kcenter_v1 | 2 | worker00523_clip003 | worker00523 | 0.5923 | 1.000 | 0.000 | Y |
| episode_000 | 2 | window_kcenter_v1 | 1 | worker00609_clip004 | worker00609 | 3.8874 | 1.000 | 0.000 | Y |
| episode_000 | 2 | window_kcenter_v1 | 2 | worker00846_clip015 | worker00846 | 3.3466 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 1 | worker00512_clip001 | worker00512 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 2 | worker00523_clip003 | worker00523 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 3 | worker00523_clip006 | worker00523 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 4 | worker00523_clip017 | worker00523 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 1 | worker00523_clip017 | worker00523 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 2 | worker00577_clip001 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 3 | worker00565_clip009 | worker00565 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 4 | worker00609_clip004 | worker00609 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 1 | worker00609_clip019 | worker00609 | 0.9866 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 2 | worker00846_clip003 | worker00846 | 0.8445 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 3 | worker00879_clip006 | worker00879 | 0.8802 | 0.998 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 4 | worker00689_clip013 | worker00689 | 0.8283 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 1 | worker00609_clip019 | worker00609 | 0.6330 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 2 | worker00523_clip003 | worker00523 | 0.5923 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 3 | worker00887_clip018 | worker00887 | 0.5203 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 4 | worker00879_clip006 | worker00879 | 0.5046 | 0.998 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 1 | worker00609_clip004 | worker00609 | 3.8874 | 1.000 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 2 | worker00846_clip015 | worker00846 | 3.3466 | 1.000 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 3 | worker00565_clip009 | worker00565 | 2.6699 | 1.000 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 4 | worker00879_clip006 | worker00879 | 2.4289 | 0.998 | 0.000 | Y |
| episode_001 | 1 | quality_only_v1 | 1 | worker00557_clip015 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | quality_stratified_random_v1 | 1 | worker00645_clip014 | worker00645 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | submitted_full_replay_v1 | 1 | worker00643_clip003 | worker00643 | 0.9179 | 0.957 | 0.009 | Y |
| episode_001 | 1 | ts2vec_kcenter_v1 | 1 | worker00643_clip003 | worker00643 | 0.5612 | 0.957 | 0.009 | Y |
| episode_001 | 1 | window_kcenter_v1 | 1 | worker00643_clip017 | worker00643 | 4.1166 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_only_v1 | 1 | worker00557_clip015 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_only_v1 | 2 | worker00557_clip017 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_stratified_random_v1 | 1 | worker00645_clip014 | worker00645 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_stratified_random_v1 | 2 | worker00643_clip017 | worker00643 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | submitted_full_replay_v1 | 1 | worker00643_clip003 | worker00643 | 0.9179 | 0.957 | 0.009 | Y |
| episode_001 | 2 | submitted_full_replay_v1 | 2 | worker00764_clip019 | worker00764 | 0.8973 | 1.000 | 0.000 | Y |
| episode_001 | 2 | ts2vec_kcenter_v1 | 1 | worker00643_clip003 | worker00643 | 0.5612 | 0.957 | 0.009 | Y |
| episode_001 | 2 | ts2vec_kcenter_v1 | 2 | worker00579_clip004 | worker00579 | 0.5488 | 1.000 | 0.000 | Y |
| episode_001 | 2 | window_kcenter_v1 | 1 | worker00643_clip017 | worker00643 | 4.1166 | 1.000 | 0.000 | Y |
| episode_001 | 2 | window_kcenter_v1 | 2 | worker00764_clip019 | worker00764 | 3.6629 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 1 | worker00557_clip015 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 2 | worker00557_clip017 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 3 | worker00561_clip005 | worker00561 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 4 | worker00579_clip004 | worker00579 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 1 | worker00645_clip014 | worker00645 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 2 | worker00643_clip017 | worker00643 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 3 | worker00557_clip017 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 4 | worker00579_clip005 | worker00579 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 1 | worker00643_clip003 | worker00643 | 0.9179 | 0.957 | 0.009 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 2 | worker00764_clip019 | worker00764 | 0.8973 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 3 | worker00643_clip017 | worker00643 | 0.8826 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 4 | worker00579_clip004 | worker00579 | 0.8160 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 1 | worker00643_clip003 | worker00643 | 0.5612 | 0.957 | 0.009 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 2 | worker00579_clip004 | worker00579 | 0.5488 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 3 | worker00561_clip009 | worker00561 | 0.4793 | 0.999 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 4 | worker00561_clip020 | worker00561 | 0.4537 | 0.985 | 0.003 | Y |
| episode_001 | 4 | window_kcenter_v1 | 1 | worker00643_clip017 | worker00643 | 4.1166 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 2 | worker00764_clip019 | worker00764 | 3.6629 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 3 | worker00643_clip003 | worker00643 | 3.2388 | 0.957 | 0.009 | Y |
| episode_001 | 4 | window_kcenter_v1 | 4 | worker00764_clip006 | worker00764 | 3.1286 | 0.981 | 0.004 | Y |
| episode_002 | 1 | quality_only_v1 | 1 | worker00512_clip001 | worker00512 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | quality_stratified_random_v1 | 1 | worker00523_clip006 | worker00523 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | submitted_full_replay_v1 | 1 | worker00609_clip019 | worker00609 | 0.9866 | 1.000 | 0.000 | Y |
| episode_002 | 1 | ts2vec_kcenter_v1 | 1 | worker00609_clip019 | worker00609 | 0.6330 | 1.000 | 0.000 | Y |
| episode_002 | 1 | window_kcenter_v1 | 1 | worker00609_clip004 | worker00609 | 3.8874 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_only_v1 | 1 | worker00512_clip001 | worker00512 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_only_v1 | 2 | worker00523_clip003 | worker00523 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_stratified_random_v1 | 1 | worker00523_clip006 | worker00523 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_stratified_random_v1 | 2 | worker00609_clip004 | worker00609 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | submitted_full_replay_v1 | 1 | worker00609_clip019 | worker00609 | 0.9866 | 1.000 | 0.000 | Y |
| episode_002 | 2 | submitted_full_replay_v1 | 2 | worker00846_clip003 | worker00846 | 0.8445 | 1.000 | 0.000 | Y |
| episode_002 | 2 | ts2vec_kcenter_v1 | 1 | worker00609_clip019 | worker00609 | 0.6330 | 1.000 | 0.000 | Y |
| episode_002 | 2 | ts2vec_kcenter_v1 | 2 | worker00523_clip003 | worker00523 | 0.5923 | 1.000 | 0.000 | Y |
| episode_002 | 2 | window_kcenter_v1 | 1 | worker00609_clip004 | worker00609 | 3.8874 | 1.000 | 0.000 | Y |
| episode_002 | 2 | window_kcenter_v1 | 2 | worker00846_clip015 | worker00846 | 3.3466 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 1 | worker00512_clip001 | worker00512 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 2 | worker00523_clip003 | worker00523 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 3 | worker00523_clip006 | worker00523 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 4 | worker00523_clip017 | worker00523 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 1 | worker00523_clip006 | worker00523 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 2 | worker00609_clip004 | worker00609 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 3 | worker00577_clip001 | worker00577 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 4 | worker00565_clip003 | worker00565 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 1 | worker00609_clip019 | worker00609 | 0.9866 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 2 | worker00846_clip003 | worker00846 | 0.8445 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 3 | worker00879_clip006 | worker00879 | 0.8802 | 0.998 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 4 | worker00689_clip013 | worker00689 | 0.8283 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 1 | worker00609_clip019 | worker00609 | 0.6330 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 2 | worker00523_clip003 | worker00523 | 0.5923 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 3 | worker00887_clip018 | worker00887 | 0.5203 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 4 | worker00879_clip006 | worker00879 | 0.5046 | 0.998 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 1 | worker00609_clip004 | worker00609 | 3.8874 | 1.000 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 2 | worker00846_clip015 | worker00846 | 3.3466 | 1.000 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 3 | worker00565_clip009 | worker00565 | 2.6699 | 1.000 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 4 | worker00879_clip006 | worker00879 | 2.4289 | 0.998 | 0.000 | Y |
| episode_003 | 1 | quality_only_v1 | 1 | worker00557_clip015 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | quality_stratified_random_v1 | 1 | worker00579_clip004 | worker00579 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | submitted_full_replay_v1 | 1 | worker00643_clip003 | worker00643 | 0.9179 | 0.957 | 0.009 | Y |
| episode_003 | 1 | ts2vec_kcenter_v1 | 1 | worker00643_clip003 | worker00643 | 0.5612 | 0.957 | 0.009 | Y |
| episode_003 | 1 | window_kcenter_v1 | 1 | worker00643_clip017 | worker00643 | 4.1166 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_only_v1 | 1 | worker00557_clip015 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_only_v1 | 2 | worker00557_clip017 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_stratified_random_v1 | 1 | worker00579_clip004 | worker00579 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_stratified_random_v1 | 2 | worker00645_clip014 | worker00645 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | submitted_full_replay_v1 | 1 | worker00643_clip003 | worker00643 | 0.9179 | 0.957 | 0.009 | Y |
| episode_003 | 2 | submitted_full_replay_v1 | 2 | worker00764_clip019 | worker00764 | 0.8973 | 1.000 | 0.000 | Y |
| episode_003 | 2 | ts2vec_kcenter_v1 | 1 | worker00643_clip003 | worker00643 | 0.5612 | 0.957 | 0.009 | Y |
| episode_003 | 2 | ts2vec_kcenter_v1 | 2 | worker00579_clip004 | worker00579 | 0.5488 | 1.000 | 0.000 | Y |
| episode_003 | 2 | window_kcenter_v1 | 1 | worker00643_clip017 | worker00643 | 4.1166 | 1.000 | 0.000 | Y |
| episode_003 | 2 | window_kcenter_v1 | 2 | worker00764_clip019 | worker00764 | 3.6629 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 1 | worker00557_clip015 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 2 | worker00557_clip017 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 3 | worker00561_clip005 | worker00561 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 4 | worker00579_clip004 | worker00579 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 1 | worker00579_clip004 | worker00579 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 2 | worker00645_clip014 | worker00645 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 3 | worker00557_clip015 | worker00557 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 4 | worker00561_clip005 | worker00561 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 1 | worker00643_clip003 | worker00643 | 0.9179 | 0.957 | 0.009 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 2 | worker00764_clip019 | worker00764 | 0.8973 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 3 | worker00643_clip017 | worker00643 | 0.8826 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 4 | worker00579_clip004 | worker00579 | 0.8160 | 1.000 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 1 | worker00643_clip003 | worker00643 | 0.5612 | 0.957 | 0.009 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 2 | worker00579_clip004 | worker00579 | 0.5488 | 1.000 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 3 | worker00561_clip009 | worker00561 | 0.4793 | 0.999 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 4 | worker00561_clip020 | worker00561 | 0.4537 | 0.985 | 0.003 | Y |
| episode_003 | 4 | window_kcenter_v1 | 1 | worker00643_clip017 | worker00643 | 4.1166 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 2 | worker00764_clip019 | worker00764 | 3.6629 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 3 | worker00643_clip003 | worker00643 | 3.2388 | 0.957 | 0.009 | Y |
| episode_003 | 4 | window_kcenter_v1 | 4 | worker00764_clip006 | worker00764 | 3.1286 | 0.981 | 0.004 | Y |

## Decision Notes

- Primary rows exclude same-feature-family selector/eval comparisons.
- Oracle rows, when present, are diagnostics because they inspect the target set.
- Deployable v1 policies only select candidates that pass quality and artifact gates.
