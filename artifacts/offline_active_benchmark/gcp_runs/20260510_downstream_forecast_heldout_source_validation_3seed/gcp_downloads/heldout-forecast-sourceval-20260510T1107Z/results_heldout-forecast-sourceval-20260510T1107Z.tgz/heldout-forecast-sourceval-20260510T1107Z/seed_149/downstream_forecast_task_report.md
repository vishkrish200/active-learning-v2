# Downstream Forecast Task

Actual Downstream Model Update: selected raw IMU clips are added to support, a ridge autoregressive forecaster is retrained, and held-out target forecast MSE is measured.

## Decision

- downstream task: `raw_imu_autoregressive_forecast`
- model update: `actual_retrain_after_acquisition`
- large training: `hold_until_repeated_real_task_runs`
- top policy: `window_kcenter_v1`
- baseline policy: `quality_stratified_random_v1`
- after-MSE delta vs baseline: `0.001194`
- relative reduction delta vs baseline: `0.002224`
- read: Actual downstream model-update task: raw IMU autoregressive forecaster is retrained after acquisition; this is not a source-family pseudo-label proxy.

## Final Means

| policy | after MSE | relative reduction | rows |
|---|---:|---:|---:|
| `quality_only_v1` | 0.324390 | 0.007180 | 4 |
| `window_kcenter_v1` | 0.327141 | 0.002444 | 4 |
| `ts2vec_kcenter_v1` | 0.327244 | 0.001592 | 4 |
| `submitted_full_replay_v1` | 0.327506 | 0.001355 | 4 |
| `quality_stratified_random_v1` | 0.328336 | 0.000220 | 4 |

## Budget Means

| policy | budget | after MSE | relative reduction | rows |
|---|---:|---:|---:|---:|
| `quality_only_v1` | 0 | 0.328412 | 0.000000 | 4 |
| `quality_only_v1` | 1 | 0.324427 | 0.007042 | 4 |
| `quality_only_v1` | 2 | 0.324420 | 0.007052 | 4 |
| `quality_only_v1` | 4 | 0.324390 | 0.007180 | 4 |
| `quality_stratified_random_v1` | 0 | 0.328412 | 0.000000 | 4 |
| `quality_stratified_random_v1` | 1 | 0.328388 | 0.000136 | 4 |
| `quality_stratified_random_v1` | 2 | 0.328368 | 0.000314 | 4 |
| `quality_stratified_random_v1` | 4 | 0.328336 | 0.000220 | 4 |
| `submitted_full_replay_v1` | 0 | 0.328412 | 0.000000 | 4 |
| `submitted_full_replay_v1` | 1 | 0.328525 | -0.000980 | 4 |
| `submitted_full_replay_v1` | 2 | 0.328393 | -0.000549 | 4 |
| `submitted_full_replay_v1` | 4 | 0.327506 | 0.001355 | 4 |
| `ts2vec_kcenter_v1` | 0 | 0.328412 | 0.000000 | 4 |
| `ts2vec_kcenter_v1` | 1 | 0.328525 | -0.000980 | 4 |
| `ts2vec_kcenter_v1` | 2 | 0.328500 | -0.000823 | 4 |
| `ts2vec_kcenter_v1` | 4 | 0.327244 | 0.001592 | 4 |
| `window_kcenter_v1` | 0 | 0.328412 | 0.000000 | 4 |
| `window_kcenter_v1` | 1 | 0.328378 | 0.000276 | 4 |
| `window_kcenter_v1` | 2 | 0.328253 | 0.000666 | 4 |
| `window_kcenter_v1` | 4 | 0.327141 | 0.002444 | 4 |

## Caveat

- This is a real model update task, but it is still a small linear forecaster, not final challenge-label training.
- Budget `0` is the support-only model. Later budgets retrain after adding selected candidate clips.
