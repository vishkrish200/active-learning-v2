# Blind Target Coverage Benchmark

## Run

- episodes: `6`
- policies: `quality_stratified_random_v1, quality_only_v1, window_kcenter_v1, submitted_full_replay_v1, ts2vec_kcenter_v1, oracle_greedy_target_family_v1`
- budgets: `1, 2, 4`
- eval views: `ts2vec, window, raw_shape_stats`
- primary eval views: `window, raw_shape_stats`
- distance metric: `euclidean`

## Policy Summary

| policy | mean primary coverage_gain_rel | primary rows | diagnostic rows | underfilled rounds |
|---|---:|---:|---:|---:|
| oracle_greedy_target_family_v1 | 0.0000 | 0 | 54 | 0 |
| quality_only_v1 | 0.0105 | 36 | 18 | 0 |
| quality_stratified_random_v1 | 0.0388 | 36 | 18 | 0 |
| submitted_full_replay_v1 | 0.1356 | 18 | 36 | 0 |
| ts2vec_kcenter_v1 | 0.1020 | 36 | 18 | 0 |
| window_kcenter_v1 | 0.1265 | 18 | 36 | 0 |

## Coverage Rows

| episode | budget | policy | eval view | metric | value | primary | feature overlap | target-used |
|---|---:|---|---|---|---:|---|---|---|
| episode_000 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 9.9408 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.2246 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.2209 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.2783 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 2.4422 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.2690 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 6.2537 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.1379 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0012 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0015 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.6418 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0629 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 9.9390 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2246 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.2208 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.2782 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 2.4419 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.2689 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 8.4769 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1911 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0226 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0292 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 1.0562 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1061 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 9.9390 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2246 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.2208 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.2782 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 2.4419 | N | Y | N |
| episode_000 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.2689 | N | Y | N |
| episode_000 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_000 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 10.0252 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.2291 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.2272 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.2859 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 2.4777 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.2819 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 9.3226 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.2091 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0226 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0292 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 1.0562 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.1061 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 9.9390 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2246 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.2208 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.2782 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 2.4419 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.2689 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 8.4769 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1911 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0287 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0380 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 1.0691 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1112 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 9.9390 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2246 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.2208 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.2782 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 2.4419 | N | Y | N |
| episode_000 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.2689 | N | Y | N |
| episode_000 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_000 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 10.6067 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.2439 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.2505 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.3202 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.2778 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 2.5414 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.3069 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0845 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0045 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0062 | N | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0076 | N | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0355 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0129 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 9.3263 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.2092 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0226 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0292 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 1.0562 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.1061 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 11.0054 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2492 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.2429 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.3102 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.2778 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 2.5055 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.2939 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 8.9079 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2013 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0885 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1097 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 1.0691 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1112 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 9.9390 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2246 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.2208 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.2782 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 2.4419 | N | Y | N |
| episode_000 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.2689 | N | Y | N |
| episode_000 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_001 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.4131 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0076 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0001 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2696 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0373 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.2615 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0347 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.2129 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0115 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.5488 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0101 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.1099 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0063 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.5488 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0101 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.6260 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0191 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0001 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2696 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0373 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.2615 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0347 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 1.4743 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0462 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 2.3700 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0646 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0130 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0148 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.7501 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1249 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 1.3714 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0410 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.5596 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0104 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0033 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0037 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.2810 | N | Y | N |
| episode_001 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0389 | N | Y | N |
| episode_001 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.9768 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0297 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0001 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2875 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0426 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.2615 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0347 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 1.7985 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0522 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0033 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0037 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.2810 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0389 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 3.2216 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0870 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0130 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0148 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.7501 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1249 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 3.3315 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0933 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0130 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0148 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.7501 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1249 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 1.8103 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0448 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0033 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0037 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.2810 | N | Y | N |
| episode_001 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0389 | N | Y | N |
| episode_001 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 9.9408 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.2246 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.2209 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.2783 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 2.4422 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.2690 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 9.9390 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2246 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.2208 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.2782 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 2.4419 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.2689 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 8.4769 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1911 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0226 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0292 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 1.0562 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1061 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 9.9390 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2246 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.2208 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.2782 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 2.4419 | N | Y | N |
| episode_002 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.2689 | N | Y | N |
| episode_002 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_002 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 10.0252 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.2291 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.2272 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.2859 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 2.4777 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.2819 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 9.9390 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2246 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.2208 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.2782 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 2.4419 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.2689 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 8.4769 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1911 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0287 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0380 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 1.0691 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1112 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 9.9390 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2246 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.2208 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.2782 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 2.4419 | N | Y | N |
| episode_002 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.2689 | N | Y | N |
| episode_002 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_002 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 10.6067 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.2439 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.2505 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.3202 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.2778 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 2.5414 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.3069 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0845 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0045 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0062 | N | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0076 | N | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0355 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0129 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 6.3082 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.1391 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0113 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0140 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.6466 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0634 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 11.0054 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2492 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.2429 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.3102 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.2778 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 2.5055 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.2939 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 8.9079 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2013 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0885 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1097 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 1.0691 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1112 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 9.9390 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2246 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.2208 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.2782 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 2.4419 | N | Y | N |
| episode_002 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.2689 | N | Y | N |
| episode_002 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_003 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.4131 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0076 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0001 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2696 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0373 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.2615 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0347 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.5488 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0101 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.1099 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0063 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.5488 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0101 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.6260 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0191 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0001 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2696 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0373 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.2615 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0347 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 1.2615 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0347 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 2.3700 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0646 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0130 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0148 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.7501 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1249 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 1.3714 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0410 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.5596 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0104 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0033 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0037 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.2810 | N | Y | N |
| episode_003 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0389 | N | Y | N |
| episode_003 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.9768 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0297 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0001 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2875 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0426 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.2615 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0347 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 1.7985 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0522 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0033 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0037 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.2810 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0389 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 3.2216 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0870 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0130 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0148 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.7501 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1249 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 3.3315 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0933 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0130 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0148 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.7501 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1249 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 1.8103 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0448 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0033 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0037 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.2810 | N | Y | N |
| episode_003 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0389 | N | Y | N |
| episode_003 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.3312 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0139 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0638 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0073 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_004 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0161 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0045 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 9.6842 | Y | N | N |
| episode_004 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2169 | Y | N | N |
| episode_004 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_004 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.1191 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.1569 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 1.6001 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1845 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 9.6842 | Y | N | N |
| episode_004 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2169 | Y | N | N |
| episode_004 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_004 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1191 | N | N | N |
| episode_004 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1569 | N | N | N |
| episode_004 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | N |
| episode_004 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 1.6001 | N | Y | N |
| episode_004 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.1845 | N | Y | N |
| episode_004 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_004 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.3312 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0139 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0799 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0118 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_004 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.2406 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0049 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0161 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0045 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 10.4840 | Y | N | N |
| episode_004 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2352 | Y | N | N |
| episode_004 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_004 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.1191 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.1569 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 1.6001 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1845 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 9.6842 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2169 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1191 | N | Y | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1569 | N | Y | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 1.6001 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1845 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_004 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 10.4840 | Y | N | N |
| episode_004 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2352 | Y | N | N |
| episode_004 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_004 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1191 | N | N | N |
| episode_004 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1569 | N | N | N |
| episode_004 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | N |
| episode_004 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 1.6001 | N | Y | N |
| episode_004 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.1845 | N | Y | N |
| episode_004 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_004 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.4197 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0163 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0803 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0119 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_004 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.7232 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0167 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0319 | N | N | N |
| episode_004 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0471 | N | N | N |
| episode_004 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_004 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.5481 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0734 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.2783 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0186 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0222 | N | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0378 | N | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.2881 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0584 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 10.5006 | Y | N | N |
| episode_004 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2365 | Y | N | N |
| episode_004 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_004 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.1191 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.1569 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 1.6001 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1845 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 10.4853 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2352 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1191 | N | Y | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1569 | N | Y | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 1.6001 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1845 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_004 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 10.4840 | Y | N | N |
| episode_004 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2352 | Y | N | N |
| episode_004 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_004 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1191 | N | N | N |
| episode_004 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1569 | N | N | N |
| episode_004 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | N |
| episode_004 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 1.6001 | N | Y | N |
| episode_004 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.1845 | N | Y | N |
| episode_004 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_005 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.5103 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0347 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0760 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0794 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.4913 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1085 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0556 | N | N | Y |
| episode_005 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.2754 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0138 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_005 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_005 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.5103 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0347 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0760 | N | Y | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0794 | N | Y | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.4913 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1085 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_005 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_005 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_005 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_005 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_005 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 2.5192 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1157 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.1266 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.1456 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.7316 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1755 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_005 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.2754 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0138 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_005 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_005 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0856 | Y | N | N |
| episode_005 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0053 | Y | N | N |
| episode_005 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_005 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0925 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0953 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.3810 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0799 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.7857 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0484 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0760 | N | Y | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0794 | N | Y | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.4913 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1085 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_005 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.2754 | Y | N | N |
| episode_005 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0138 | Y | N | N |
| episode_005 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_005 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_005 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_005 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_005 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_005 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 2.8233 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1309 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.1266 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.1456 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.7316 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1755 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_005 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.2754 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0138 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_005 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_005 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0235 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0017 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.4795 | Y | N | N |
| episode_005 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0270 | Y | N | N |
| episode_005 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_005 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0925 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0953 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.4647 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1035 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 1.2336 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0821 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0760 | N | Y | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0794 | N | Y | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.5060 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1148 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_005 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.3259 | Y | N | N |
| episode_005 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0976 | Y | N | N |
| episode_005 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.2222 | Y | N | N |
| episode_005 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1431 | N | N | N |
| episode_005 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1615 | N | N | N |
| episode_005 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.3333 | N | N | N |
| episode_005 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.6966 | N | Y | N |
| episode_005 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.1633 | N | Y | N |
| episode_005 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.1111 | N | Y | N |

## Hygiene Rows

| episode | budget | policy | metric | value |
|---|---:|---|---|---:|
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_000 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_000 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_000 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_001 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_001 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_001 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_002 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_002 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_002 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_003 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_003 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_003 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_004 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_004 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_004 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_005 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_005 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_005 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |

## Selected Clips

| episode | budget | policy | rank | sample | source | score | quality | artifact | valid |
|---|---:|---|---:|---|---|---:|---:|---:|---|
| episode_000 | 1 | oracle_greedy_target_family_v1 | 1 | worker01063_clip007 | worker01063 | 0.5000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | quality_only_v1 | 1 | worker00930_clip001 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | quality_stratified_random_v1 | 1 | worker01021_clip009 | worker01021 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | submitted_full_replay_v1 | 1 | worker01063_clip017 | worker01063 | 0.8980 | 0.999 | 0.000 | Y |
| episode_000 | 1 | ts2vec_kcenter_v1 | 1 | worker01021_clip011 | worker01021 | 0.9096 | 1.000 | 0.000 | Y |
| episode_000 | 1 | window_kcenter_v1 | 1 | worker01063_clip017 | worker01063 | 9.7561 | 0.999 | 0.000 | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | 1 | worker01063_clip007 | worker01063 | 0.5000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | 2 | worker00957_clip017 | worker00957 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_only_v1 | 1 | worker00930_clip001 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_only_v1 | 2 | worker00930_clip016 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_stratified_random_v1 | 1 | worker01021_clip009 | worker01021 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_stratified_random_v1 | 2 | worker01021_clip011 | worker01021 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | submitted_full_replay_v1 | 1 | worker01063_clip017 | worker01063 | 0.8980 | 0.999 | 0.000 | Y |
| episode_000 | 2 | submitted_full_replay_v1 | 2 | worker00957_clip005 | worker00957 | 0.8249 | 1.000 | 0.000 | Y |
| episode_000 | 2 | ts2vec_kcenter_v1 | 1 | worker01021_clip011 | worker01021 | 0.9096 | 1.000 | 0.000 | Y |
| episode_000 | 2 | ts2vec_kcenter_v1 | 2 | worker01073_clip009 | worker01073 | 0.8667 | 1.000 | 0.000 | Y |
| episode_000 | 2 | window_kcenter_v1 | 1 | worker01063_clip017 | worker01063 | 9.7561 | 0.999 | 0.000 | Y |
| episode_000 | 2 | window_kcenter_v1 | 2 | worker00957_clip005 | worker00957 | 7.1226 | 1.000 | 0.000 | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | 1 | worker01063_clip007 | worker01063 | 0.5000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | 2 | worker00957_clip017 | worker00957 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | 3 | worker01161_clip011 | worker01161 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | 4 | worker01161_clip005 | worker01161 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 1 | worker00930_clip001 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 2 | worker00930_clip016 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 3 | worker00957_clip005 | worker00957 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 4 | worker00957_clip017 | worker00957 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 1 | worker01021_clip009 | worker01021 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 2 | worker01021_clip011 | worker01021 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 3 | worker01021_clip004 | worker01021 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 4 | worker00930_clip001 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 1 | worker01063_clip017 | worker01063 | 0.8980 | 0.999 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 2 | worker00957_clip005 | worker00957 | 0.8249 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 3 | worker01021_clip009 | worker01021 | 0.9076 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 4 | worker01161_clip011 | worker01161 | 0.8449 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 1 | worker01021_clip011 | worker01021 | 0.9096 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 2 | worker01073_clip009 | worker01073 | 0.8667 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 3 | worker01045_clip011 | worker01045 | 0.7264 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 4 | worker01131_clip019 | worker01131 | 0.7107 | 1.000 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 1 | worker01063_clip017 | worker01063 | 9.7561 | 0.999 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 2 | worker00957_clip005 | worker00957 | 7.1226 | 1.000 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 3 | worker01021_clip011 | worker01021 | 5.3338 | 1.000 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 4 | worker01045_clip014 | worker01045 | 4.0302 | 1.000 | 0.000 | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | 1 | worker00930_clip016 | worker00930 | 0.5000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | quality_only_v1 | 1 | worker00908_clip005 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | quality_stratified_random_v1 | 1 | worker00915_clip006 | worker00915 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | submitted_full_replay_v1 | 1 | worker01178_clip001 | worker01178 | 0.7777 | 0.982 | 0.004 | Y |
| episode_001 | 1 | ts2vec_kcenter_v1 | 1 | worker00915_clip002 | worker00915 | 1.0356 | 0.954 | 0.009 | Y |
| episode_001 | 1 | window_kcenter_v1 | 1 | worker01178_clip001 | worker01178 | 7.1517 | 0.982 | 0.004 | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | 1 | worker00930_clip016 | worker00930 | 0.5000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | 2 | worker00915_clip006 | worker00915 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_only_v1 | 1 | worker00908_clip005 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_only_v1 | 2 | worker00908_clip017 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_stratified_random_v1 | 1 | worker00915_clip006 | worker00915 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_stratified_random_v1 | 2 | worker00908_clip005 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | submitted_full_replay_v1 | 1 | worker01178_clip001 | worker01178 | 0.7777 | 0.982 | 0.004 | Y |
| episode_001 | 2 | submitted_full_replay_v1 | 2 | worker00930_clip001 | worker00930 | 0.8223 | 1.000 | 0.000 | Y |
| episode_001 | 2 | ts2vec_kcenter_v1 | 1 | worker00915_clip002 | worker00915 | 1.0356 | 0.954 | 0.009 | Y |
| episode_001 | 2 | ts2vec_kcenter_v1 | 2 | worker00908_clip005 | worker00908 | 0.8387 | 1.000 | 0.000 | Y |
| episode_001 | 2 | window_kcenter_v1 | 1 | worker01178_clip001 | worker01178 | 7.1517 | 0.982 | 0.004 | Y |
| episode_001 | 2 | window_kcenter_v1 | 2 | worker00927_clip003 | worker00927 | 6.5147 | 1.000 | 0.000 | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | 1 | worker00930_clip016 | worker00930 | 0.5000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | 2 | worker00915_clip006 | worker00915 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | 3 | worker01178_clip014 | worker01178 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | 4 | worker01171_clip015 | worker01171 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 1 | worker00908_clip005 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 2 | worker00908_clip017 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 3 | worker00913_clip012 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 4 | worker00913_clip017 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 1 | worker00915_clip006 | worker00915 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 2 | worker00908_clip005 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 3 | worker00913_clip017 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 4 | worker00927_clip003 | worker00927 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 1 | worker01178_clip001 | worker01178 | 0.7777 | 0.982 | 0.004 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 2 | worker00930_clip001 | worker00930 | 0.8223 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 3 | worker00908_clip005 | worker00908 | 0.8040 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 4 | worker01152_clip005 | worker01152 | 0.7253 | 0.995 | 0.001 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 1 | worker00915_clip002 | worker00915 | 1.0356 | 0.954 | 0.009 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 2 | worker00908_clip005 | worker00908 | 0.8387 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 3 | worker00930_clip001 | worker00930 | 0.7490 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 4 | worker01178_clip001 | worker01178 | 0.6466 | 0.982 | 0.004 | Y |
| episode_001 | 4 | window_kcenter_v1 | 1 | worker01178_clip001 | worker01178 | 7.1517 | 0.982 | 0.004 | Y |
| episode_001 | 4 | window_kcenter_v1 | 2 | worker00927_clip003 | worker00927 | 6.5147 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 3 | worker00908_clip005 | worker00908 | 3.7090 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 4 | worker01021_clip009 | worker01021 | 3.1063 | 1.000 | 0.000 | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | 1 | worker01063_clip007 | worker01063 | 0.5000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | quality_only_v1 | 1 | worker00930_clip001 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | quality_stratified_random_v1 | 1 | worker00930_clip016 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | submitted_full_replay_v1 | 1 | worker01063_clip017 | worker01063 | 0.8980 | 0.999 | 0.000 | Y |
| episode_002 | 1 | ts2vec_kcenter_v1 | 1 | worker01021_clip011 | worker01021 | 0.9096 | 1.000 | 0.000 | Y |
| episode_002 | 1 | window_kcenter_v1 | 1 | worker01063_clip017 | worker01063 | 9.7561 | 0.999 | 0.000 | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | 1 | worker01063_clip007 | worker01063 | 0.5000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | 2 | worker00957_clip017 | worker00957 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_only_v1 | 1 | worker00930_clip001 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_only_v1 | 2 | worker00930_clip016 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_stratified_random_v1 | 1 | worker00930_clip016 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_stratified_random_v1 | 2 | worker00930_clip001 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | submitted_full_replay_v1 | 1 | worker01063_clip017 | worker01063 | 0.8980 | 0.999 | 0.000 | Y |
| episode_002 | 2 | submitted_full_replay_v1 | 2 | worker00957_clip005 | worker00957 | 0.8249 | 1.000 | 0.000 | Y |
| episode_002 | 2 | ts2vec_kcenter_v1 | 1 | worker01021_clip011 | worker01021 | 0.9096 | 1.000 | 0.000 | Y |
| episode_002 | 2 | ts2vec_kcenter_v1 | 2 | worker01073_clip009 | worker01073 | 0.8667 | 1.000 | 0.000 | Y |
| episode_002 | 2 | window_kcenter_v1 | 1 | worker01063_clip017 | worker01063 | 9.7561 | 0.999 | 0.000 | Y |
| episode_002 | 2 | window_kcenter_v1 | 2 | worker00957_clip005 | worker00957 | 7.1226 | 1.000 | 0.000 | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | 1 | worker01063_clip007 | worker01063 | 0.5000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | 2 | worker00957_clip017 | worker00957 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | 3 | worker01161_clip011 | worker01161 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | 4 | worker01161_clip005 | worker01161 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 1 | worker00930_clip001 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 2 | worker00930_clip016 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 3 | worker00957_clip005 | worker00957 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 4 | worker00957_clip017 | worker00957 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 1 | worker00930_clip016 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 2 | worker00930_clip001 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 3 | worker01021_clip004 | worker01021 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 4 | worker01039_clip002 | worker01039 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 1 | worker01063_clip017 | worker01063 | 0.8980 | 0.999 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 2 | worker00957_clip005 | worker00957 | 0.8249 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 3 | worker01021_clip009 | worker01021 | 0.9076 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 4 | worker01161_clip011 | worker01161 | 0.8449 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 1 | worker01021_clip011 | worker01021 | 0.9096 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 2 | worker01073_clip009 | worker01073 | 0.8667 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 3 | worker01045_clip011 | worker01045 | 0.7264 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 4 | worker01131_clip019 | worker01131 | 0.7107 | 1.000 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 1 | worker01063_clip017 | worker01063 | 9.7561 | 0.999 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 2 | worker00957_clip005 | worker00957 | 7.1226 | 1.000 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 3 | worker01021_clip011 | worker01021 | 5.3338 | 1.000 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 4 | worker01045_clip014 | worker01045 | 4.0302 | 1.000 | 0.000 | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | 1 | worker00930_clip016 | worker00930 | 0.5000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | quality_only_v1 | 1 | worker00908_clip005 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | quality_stratified_random_v1 | 1 | worker00913_clip012 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | submitted_full_replay_v1 | 1 | worker01178_clip001 | worker01178 | 0.7777 | 0.982 | 0.004 | Y |
| episode_003 | 1 | ts2vec_kcenter_v1 | 1 | worker00915_clip002 | worker00915 | 1.0356 | 0.954 | 0.009 | Y |
| episode_003 | 1 | window_kcenter_v1 | 1 | worker01178_clip001 | worker01178 | 7.1517 | 0.982 | 0.004 | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | 1 | worker00930_clip016 | worker00930 | 0.5000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | 2 | worker00915_clip006 | worker00915 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_only_v1 | 1 | worker00908_clip005 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_only_v1 | 2 | worker00908_clip017 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_stratified_random_v1 | 1 | worker00913_clip012 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_stratified_random_v1 | 2 | worker00908_clip005 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | submitted_full_replay_v1 | 1 | worker01178_clip001 | worker01178 | 0.7777 | 0.982 | 0.004 | Y |
| episode_003 | 2 | submitted_full_replay_v1 | 2 | worker00930_clip001 | worker00930 | 0.8223 | 1.000 | 0.000 | Y |
| episode_003 | 2 | ts2vec_kcenter_v1 | 1 | worker00915_clip002 | worker00915 | 1.0356 | 0.954 | 0.009 | Y |
| episode_003 | 2 | ts2vec_kcenter_v1 | 2 | worker00908_clip005 | worker00908 | 0.8387 | 1.000 | 0.000 | Y |
| episode_003 | 2 | window_kcenter_v1 | 1 | worker01178_clip001 | worker01178 | 7.1517 | 0.982 | 0.004 | Y |
| episode_003 | 2 | window_kcenter_v1 | 2 | worker00927_clip003 | worker00927 | 6.5147 | 1.000 | 0.000 | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | 1 | worker00930_clip016 | worker00930 | 0.5000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | 2 | worker00915_clip006 | worker00915 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | 3 | worker01178_clip014 | worker01178 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | 4 | worker01171_clip015 | worker01171 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 1 | worker00908_clip005 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 2 | worker00908_clip017 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 3 | worker00913_clip012 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 4 | worker00913_clip017 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 1 | worker00913_clip012 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 2 | worker00908_clip005 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 3 | worker00915_clip006 | worker00915 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 4 | worker00927_clip003 | worker00927 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 1 | worker01178_clip001 | worker01178 | 0.7777 | 0.982 | 0.004 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 2 | worker00930_clip001 | worker00930 | 0.8223 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 3 | worker00908_clip005 | worker00908 | 0.8040 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 4 | worker01152_clip005 | worker01152 | 0.7253 | 0.995 | 0.001 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 1 | worker00915_clip002 | worker00915 | 1.0356 | 0.954 | 0.009 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 2 | worker00908_clip005 | worker00908 | 0.8387 | 1.000 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 3 | worker00930_clip001 | worker00930 | 0.7490 | 1.000 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 4 | worker01178_clip001 | worker01178 | 0.6466 | 0.982 | 0.004 | Y |
| episode_003 | 4 | window_kcenter_v1 | 1 | worker01178_clip001 | worker01178 | 7.1517 | 0.982 | 0.004 | Y |
| episode_003 | 4 | window_kcenter_v1 | 2 | worker00927_clip003 | worker00927 | 6.5147 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 3 | worker00908_clip005 | worker00908 | 3.7090 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 4 | worker01021_clip009 | worker01021 | 3.1063 | 1.000 | 0.000 | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | 1 | worker01152_clip014 | worker01152 | 0.5000 | 1.000 | 0.000 | Y |
| episode_004 | 1 | quality_only_v1 | 1 | worker00930_clip001 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 1 | quality_stratified_random_v1 | 1 | worker01040_clip009 | worker01040 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 1 | submitted_full_replay_v1 | 1 | worker01118_clip017 | worker01118 | 0.9599 | 1.000 | 0.000 | Y |
| episode_004 | 1 | ts2vec_kcenter_v1 | 1 | worker01073_clip009 | worker01073 | 0.8667 | 1.000 | 0.000 | Y |
| episode_004 | 1 | window_kcenter_v1 | 1 | worker01118_clip017 | worker01118 | 7.1324 | 1.000 | 0.000 | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | 1 | worker01152_clip014 | worker01152 | 0.5000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | 2 | worker01040_clip009 | worker01040 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | quality_only_v1 | 1 | worker00930_clip001 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | quality_only_v1 | 2 | worker00930_clip016 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | quality_stratified_random_v1 | 1 | worker01040_clip009 | worker01040 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | quality_stratified_random_v1 | 2 | worker00937_clip012 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | submitted_full_replay_v1 | 1 | worker01118_clip017 | worker01118 | 0.9599 | 1.000 | 0.000 | Y |
| episode_004 | 2 | submitted_full_replay_v1 | 2 | worker01131_clip016 | worker01131 | 0.9080 | 1.000 | 0.000 | Y |
| episode_004 | 2 | ts2vec_kcenter_v1 | 1 | worker01073_clip009 | worker01073 | 0.8667 | 1.000 | 0.000 | Y |
| episode_004 | 2 | ts2vec_kcenter_v1 | 2 | worker01118_clip017 | worker01118 | 0.8033 | 1.000 | 0.000 | Y |
| episode_004 | 2 | window_kcenter_v1 | 1 | worker01118_clip017 | worker01118 | 7.1324 | 1.000 | 0.000 | Y |
| episode_004 | 2 | window_kcenter_v1 | 2 | worker01131_clip016 | worker01131 | 4.0912 | 1.000 | 0.000 | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | 1 | worker01152_clip014 | worker01152 | 0.5000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | 2 | worker01040_clip009 | worker01040 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | 3 | worker01161_clip011 | worker01161 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | 4 | worker01161_clip005 | worker01161 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_only_v1 | 1 | worker00930_clip001 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_only_v1 | 2 | worker00930_clip016 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_only_v1 | 3 | worker00937_clip012 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_only_v1 | 4 | worker01003_clip002 | worker01003 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_stratified_random_v1 | 1 | worker01040_clip009 | worker01040 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_stratified_random_v1 | 2 | worker00937_clip012 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_stratified_random_v1 | 3 | worker01003_clip005 | worker01003 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_stratified_random_v1 | 4 | worker00930_clip001 | worker00930 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | submitted_full_replay_v1 | 1 | worker01118_clip017 | worker01118 | 0.9599 | 1.000 | 0.000 | Y |
| episode_004 | 4 | submitted_full_replay_v1 | 2 | worker01131_clip016 | worker01131 | 0.9080 | 1.000 | 0.000 | Y |
| episode_004 | 4 | submitted_full_replay_v1 | 3 | worker01045_clip014 | worker01045 | 0.8817 | 1.000 | 0.000 | Y |
| episode_004 | 4 | submitted_full_replay_v1 | 4 | worker01161_clip011 | worker01161 | 0.9224 | 1.000 | 0.000 | Y |
| episode_004 | 4 | ts2vec_kcenter_v1 | 1 | worker01073_clip009 | worker01073 | 0.8667 | 1.000 | 0.000 | Y |
| episode_004 | 4 | ts2vec_kcenter_v1 | 2 | worker01118_clip017 | worker01118 | 0.8033 | 1.000 | 0.000 | Y |
| episode_004 | 4 | ts2vec_kcenter_v1 | 3 | worker01131_clip019 | worker01131 | 0.7107 | 1.000 | 0.000 | Y |
| episode_004 | 4 | ts2vec_kcenter_v1 | 4 | worker01045_clip011 | worker01045 | 0.6640 | 1.000 | 0.000 | Y |
| episode_004 | 4 | window_kcenter_v1 | 1 | worker01118_clip017 | worker01118 | 7.1324 | 1.000 | 0.000 | Y |
| episode_004 | 4 | window_kcenter_v1 | 2 | worker01131_clip016 | worker01131 | 4.0912 | 1.000 | 0.000 | Y |
| episode_004 | 4 | window_kcenter_v1 | 3 | worker01045_clip014 | worker01045 | 4.0302 | 1.000 | 0.000 | Y |
| episode_004 | 4 | window_kcenter_v1 | 4 | worker01152_clip005 | worker01152 | 3.2123 | 0.995 | 0.001 | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | 1 | worker01008_clip010 | worker01008 | 0.5000 | 1.000 | 0.000 | Y |
| episode_005 | 1 | quality_only_v1 | 1 | worker00908_clip005 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 1 | quality_stratified_random_v1 | 1 | worker00914_clip012 | worker00914 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 1 | submitted_full_replay_v1 | 1 | worker01178_clip001 | worker01178 | 0.8101 | 0.982 | 0.004 | Y |
| episode_005 | 1 | ts2vec_kcenter_v1 | 1 | worker01008_clip010 | worker01008 | 0.8930 | 1.000 | 0.000 | Y |
| episode_005 | 1 | window_kcenter_v1 | 1 | worker01178_clip001 | worker01178 | 7.1517 | 0.982 | 0.004 | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | 1 | worker01008_clip010 | worker01008 | 0.5000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | 2 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | quality_only_v1 | 1 | worker00908_clip005 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | quality_only_v1 | 2 | worker00908_clip017 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | quality_stratified_random_v1 | 1 | worker00914_clip012 | worker00914 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | quality_stratified_random_v1 | 2 | worker00914_clip002 | worker00914 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | submitted_full_replay_v1 | 1 | worker01178_clip001 | worker01178 | 0.8101 | 0.982 | 0.004 | Y |
| episode_005 | 2 | submitted_full_replay_v1 | 2 | worker01001_clip005 | worker01001 | 0.9337 | 0.998 | 0.000 | Y |
| episode_005 | 2 | ts2vec_kcenter_v1 | 1 | worker01008_clip010 | worker01008 | 0.8930 | 1.000 | 0.000 | Y |
| episode_005 | 2 | ts2vec_kcenter_v1 | 2 | worker00908_clip005 | worker00908 | 0.8387 | 1.000 | 0.000 | Y |
| episode_005 | 2 | window_kcenter_v1 | 1 | worker01178_clip001 | worker01178 | 7.1517 | 0.982 | 0.004 | Y |
| episode_005 | 2 | window_kcenter_v1 | 2 | worker00908_clip005 | worker00908 | 3.7090 | 1.000 | 0.000 | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | 1 | worker01008_clip010 | worker01008 | 0.5000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | 2 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | 3 | worker01178_clip014 | worker01178 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | 4 | worker01152_clip014 | worker01152 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_only_v1 | 1 | worker00908_clip005 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_only_v1 | 2 | worker00908_clip017 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_only_v1 | 3 | worker00914_clip002 | worker00914 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_only_v1 | 4 | worker00914_clip008 | worker00914 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_stratified_random_v1 | 1 | worker00914_clip012 | worker00914 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_stratified_random_v1 | 2 | worker00914_clip002 | worker00914 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_stratified_random_v1 | 3 | worker00928_clip016 | worker00928 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_stratified_random_v1 | 4 | worker00928_clip017 | worker00928 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | submitted_full_replay_v1 | 1 | worker01178_clip001 | worker01178 | 0.8101 | 0.982 | 0.004 | Y |
| episode_005 | 4 | submitted_full_replay_v1 | 2 | worker01001_clip005 | worker01001 | 0.9337 | 0.998 | 0.000 | Y |
| episode_005 | 4 | submitted_full_replay_v1 | 3 | worker00908_clip005 | worker00908 | 0.8660 | 1.000 | 0.000 | Y |
| episode_005 | 4 | submitted_full_replay_v1 | 4 | worker01008_clip003 | worker01008 | 0.8526 | 1.000 | 0.000 | Y |
| episode_005 | 4 | ts2vec_kcenter_v1 | 1 | worker01008_clip010 | worker01008 | 0.8930 | 1.000 | 0.000 | Y |
| episode_005 | 4 | ts2vec_kcenter_v1 | 2 | worker00908_clip005 | worker00908 | 0.8387 | 1.000 | 0.000 | Y |
| episode_005 | 4 | ts2vec_kcenter_v1 | 3 | worker00933_clip009 | worker00933 | 0.6597 | 0.940 | 0.012 | Y |
| episode_005 | 4 | ts2vec_kcenter_v1 | 4 | worker01178_clip001 | worker01178 | 0.6466 | 0.982 | 0.004 | Y |
| episode_005 | 4 | window_kcenter_v1 | 1 | worker01178_clip001 | worker01178 | 7.1517 | 0.982 | 0.004 | Y |
| episode_005 | 4 | window_kcenter_v1 | 2 | worker00908_clip005 | worker00908 | 3.7090 | 1.000 | 0.000 | Y |
| episode_005 | 4 | window_kcenter_v1 | 3 | worker01001_clip005 | worker01001 | 3.6884 | 0.998 | 0.000 | Y |
| episode_005 | 4 | window_kcenter_v1 | 4 | worker00933_clip014 | worker00933 | 3.2128 | 1.000 | 0.000 | Y |

## Decision Notes

- Primary rows exclude same-feature-family selector/eval comparisons.
- Oracle rows, when present, are diagnostics because they inspect the target set.
- Deployable v1 policies only select candidates that pass quality and artifact gates.
