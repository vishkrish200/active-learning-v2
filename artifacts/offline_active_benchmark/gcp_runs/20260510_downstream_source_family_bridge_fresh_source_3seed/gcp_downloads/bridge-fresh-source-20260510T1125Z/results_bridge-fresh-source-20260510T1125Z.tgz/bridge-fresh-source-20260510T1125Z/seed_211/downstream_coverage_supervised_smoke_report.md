# Downstream Coverage Supervised Smoke

This is a source-family pseudo-label frozen-feature supervised probe, not real challenge-label downstream proof.

## Decision

- downstream training: `hold_large_training`
- read: source-family pseudo-label bridge downstream benchmark ran with predeclared frozen model heads; keep this as an identifiability gate and do not treat it as real challenge-label downstream proof.
- top policy: `window_kcenter_v1`
- baseline policy: `quality_stratified_random_v1`
- target-family discovery delta vs baseline: `0.083333`
- balanced accuracy delta vs baseline: `-0.081019`
- NLL delta vs baseline: `0.221954`

## Run

- episodes: `6`
- budgets: `0, 1, 2, 4`
- downstream representations: `window, raw_shape_stats`
- downstream model heads: `nearest_centroid, ridge_classifier`

## Budget Means

| policy | budget | discovery rate | bridge clips | balanced accuracy gain | NLL reduction | after known target frac | rows |
|---|---:|---:|---:|---:|---:|---:|---:|
| oracle_greedy_target_family_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| oracle_greedy_target_family_v1 | 1 | 0.500000 | 1.000000 | 0.159722 | 11.544036 | 0.500000 | 24 |
| oracle_greedy_target_family_v1 | 2 | 1.000000 | 2.000000 | 0.321759 | 22.791870 | 1.000000 | 24 |
| oracle_greedy_target_family_v1 | 4 | 1.000000 | 2.000000 | 0.321759 | 22.774750 | 1.000000 | 24 |
| quality_only_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| quality_only_v1 | 1 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| quality_only_v1 | 2 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| quality_only_v1 | 4 | 0.416667 | 1.500000 | 0.136574 | 9.376279 | 0.416667 | 24 |
| quality_stratified_random_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| quality_stratified_random_v1 | 1 | 0.333333 | 0.666667 | 0.148148 | 8.302622 | 0.333333 | 24 |
| quality_stratified_random_v1 | 2 | 0.333333 | 0.833333 | 0.136574 | 8.290188 | 0.333333 | 24 |
| quality_stratified_random_v1 | 4 | 0.666667 | 2.333333 | 0.245370 | 15.269822 | 0.666667 | 24 |
| submitted_full_replay_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| submitted_full_replay_v1 | 1 | 0.250000 | 0.500000 | 0.094907 | 5.950343 | 0.250000 | 24 |
| submitted_full_replay_v1 | 2 | 0.666667 | 1.333333 | 0.185185 | 13.900854 | 0.666667 | 24 |
| submitted_full_replay_v1 | 4 | 0.666667 | 1.833333 | 0.185185 | 14.038710 | 0.666667 | 24 |
| ts2vec_kcenter_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| ts2vec_kcenter_v1 | 1 | 0.416667 | 0.833333 | 0.166667 | 10.110722 | 0.416667 | 24 |
| ts2vec_kcenter_v1 | 2 | 0.500000 | 1.000000 | 0.182870 | 12.041967 | 0.500000 | 24 |
| ts2vec_kcenter_v1 | 4 | 0.750000 | 1.500000 | 0.243056 | 17.740141 | 0.750000 | 24 |
| window_kcenter_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| window_kcenter_v1 | 1 | 0.250000 | 0.500000 | 0.094907 | 5.950343 | 0.250000 | 24 |
| window_kcenter_v1 | 2 | 0.583333 | 1.166667 | 0.108796 | 11.675411 | 0.583333 | 24 |
| window_kcenter_v1 | 4 | 0.750000 | 2.000000 | 0.164352 | 15.491776 | 0.750000 | 24 |

## Caveat

- Budget `0` is the support-only baseline. Later budgets add selected candidate clips to support before evaluating the pseudo-label probe.
- This checks whether acquisition changes a tiny downstream classifier/probe; it is still not a learned query policy or TS2Vec retraining proof.
