# Blind Target Coverage Benchmark

## Run

- episodes: `6`
- policies: `quality_stratified_random_v1, quality_only_v1, window_kcenter_v1, submitted_full_replay_v1, ts2vec_kcenter_v1, oracle_greedy_target_family_v1`
- budgets: `1, 2, 4`
- eval views: `ts2vec, window, raw_shape_stats`
- primary eval views: `window, raw_shape_stats`
- distance metric: `euclidean`

## Policy Summary

| policy | mean primary coverage_gain_rel | primary rows | diagnostic rows | underfilled rounds |
|---|---:|---:|---:|---:|
| oracle_greedy_target_family_v1 | 0.0000 | 0 | 54 | 0 |
| quality_only_v1 | 0.0849 | 36 | 18 | 0 |
| quality_stratified_random_v1 | 0.0732 | 36 | 18 | 0 |
| submitted_full_replay_v1 | 0.0695 | 18 | 36 | 0 |
| ts2vec_kcenter_v1 | 0.1211 | 36 | 18 | 0 |
| window_kcenter_v1 | 0.0607 | 18 | 36 | 0 |

## Coverage Rows

| episode | budget | policy | eval view | metric | value | primary | feature overlap | target-used |
|---|---:|---|---|---|---:|---|---|---|
| episode_000 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.6775 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0186 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 1.6659 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0457 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 1.6659 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0457 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0078 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0110 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0072 | N | Y | N |
| episode_000 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0008 | N | Y | N |
| episode_000 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.6659 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0457 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 1.6659 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0457 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0078 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0110 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0072 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0008 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 1.6659 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0457 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0078 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0110 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.0072 | N | Y | N |
| episode_000 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0008 | N | Y | N |
| episode_000 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.6659 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0457 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 1.6659 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0457 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0441 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0681 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.1111 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0107 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0018 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 1.6659 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0457 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0363 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0571 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.1111 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0035 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0010 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 1.6659 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0457 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0441 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0681 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.1111 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.0107 | N | Y | N |
| episode_000 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0018 | N | Y | N |
| episode_000 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0402 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0051 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0402 | N | Y | N |
| episode_001 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0051 | N | Y | N |
| episode_001 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0402 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0051 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0004 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0006 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.0402 | N | Y | N |
| episode_001 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0051 | N | Y | N |
| episode_001 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.6119 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0218 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0024 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0056 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.3866 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0776 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.6119 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0218 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0565 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0732 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.3464 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0725 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.6119 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0218 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0028 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0061 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.3866 | N | Y | N |
| episode_001 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0776 | N | Y | N |
| episode_001 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 10.7776 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.2553 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.1131 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.1122 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 8.5774 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.5304 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 6.1814 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.1486 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 1 | quality_only_v1 | window | coverage_gain_abs | 6.1641 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.3810 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0034 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0001 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 10.9411 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2593 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 8.1451 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.5075 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 10.9762 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2602 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 8.1466 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.5076 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 10.6039 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2517 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0555 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0577 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 9.0046 | N | Y | N |
| episode_002 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.5540 | N | Y | N |
| episode_002 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_002 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 11.3988 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.2700 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.1131 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.1122 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 8.8839 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.5529 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 7.1699 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.1746 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 2 | quality_only_v1 | window | coverage_gain_abs | 6.2587 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.3877 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 10.9411 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.2593 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 8.1451 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.5075 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 12.5293 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2941 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 9.9147 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.6378 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 12.5643 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2950 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 9.9158 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.6378 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 12.2133 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2870 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0555 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0577 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 10.1942 | N | Y | N |
| episode_002 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.6431 | N | Y | N |
| episode_002 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_002 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 11.4495 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.2711 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.1159 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.1168 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 8.8839 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.5529 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 13.6056 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.3275 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 4 | quality_only_v1 | window | coverage_gain_abs | 8.1469 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.5076 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 12.8952 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.3108 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 8.1481 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.5077 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 14.7511 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.3178 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.1338 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.1199 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 10.0825 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.6543 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 16.3647 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.3884 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0899 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0928 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 10.8071 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.6915 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.2222 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 14.1323 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.3376 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0588 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0606 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 10.1942 | N | Y | N |
| episode_002 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.6431 | N | Y | N |
| episode_002 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_003 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.0794 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0076 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0088 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0359 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0310 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0447 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0148 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0016 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0008 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0009 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0083 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0067 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.0878 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0080 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0212 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0530 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0771 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0630 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0556 | N | N | Y |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0148 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0016 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0008 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0009 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0083 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0067 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.0878 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0080 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0212 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0530 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0771 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0630 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0556 | N | N | Y |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.4894 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0238 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0135 | N | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0186 | N | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | N | N |
| episode_003 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0977 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0387 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.3990 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0204 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0079 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0107 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0710 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0317 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 4.4771 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.2594 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0378 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.1061 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.1176 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1028 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_004 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 4.4771 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.2594 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0378 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.1061 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.1176 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1028 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_004 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.1431 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0078 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 4.4771 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.2594 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0378 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.1061 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.1176 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1028 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_004 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.1431 | Y | N | N |
| episode_004 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0078 | Y | N | N |
| episode_004 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.1431 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0078 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 3.7416 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1477 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0327 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0315 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 1.7518 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1760 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_005 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 1.5885 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0630 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0483 | N | N | N |
| episode_005 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0458 | N | N | N |
| episode_005 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.6230 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.1202 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.1111 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 4.4813 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.1812 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0226 | N | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0223 | N | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.8398 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.1519 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.2222 | Y | N | N |
| episode_005 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.1115 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.1051 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 1.1954 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1008 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 4.5249 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1848 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0391 | N | Y | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0321 | N | Y | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.7598 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.1670 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_005 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1115 | N | N | N |
| episode_005 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1051 | N | N | N |
| episode_005 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 1.1954 | N | Y | N |
| episode_005 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.1008 | N | Y | N |
| episode_005 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 4.6357 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1864 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0553 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0538 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 1.9905 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.2552 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_005 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 4.6045 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.1848 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0765 | N | N | N |
| episode_005 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0749 | N | N | N |
| episode_005 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 2 | quality_only_v1 | window | coverage_gain_abs | 1.1736 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.1876 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.2222 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 4.4813 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.1812 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0226 | N | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0223 | N | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.8398 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.1519 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.2222 | Y | N | N |
| episode_005 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 1.4628 | Y | N | N |
| episode_005 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0515 | Y | N | N |
| episode_005 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_005 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.1115 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.1051 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 1.5477 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1535 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 4.5317 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1850 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0391 | N | Y | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0321 | N | Y | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 1.4991 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.2365 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0556 | Y | N | N |
| episode_005 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1144 | N | N | N |
| episode_005 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1081 | N | N | N |
| episode_005 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 1.1954 | N | Y | N |
| episode_005 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.1008 | N | Y | N |
| episode_005 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 4.6862 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1874 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0553 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0538 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 1.9905 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.2552 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_005 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 4.7233 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.1901 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0841 | N | N | N |
| episode_005 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0814 | N | N | N |
| episode_005 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 4 | quality_only_v1 | window | coverage_gain_abs | 1.2334 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.2129 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.2222 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 5.3925 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.2004 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.3889 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0659 | N | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0608 | N | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.9520 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.1838 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.2222 | Y | N | N |
| episode_005 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 4.1486 | Y | N | N |
| episode_005 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.1621 | Y | N | N |
| episode_005 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | Y | N | N |
| episode_005 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.1397 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.1300 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 1.6582 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1971 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 5.2205 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2063 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1430 | N | Y | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1379 | N | Y | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 1.9316 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.2843 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_005 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 3.7908 | Y | N | N |
| episode_005 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1486 | Y | N | N |
| episode_005 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.3333 | Y | N | N |
| episode_005 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1170 | N | N | N |
| episode_005 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1111 | N | N | N |
| episode_005 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 1.9858 | N | Y | N |
| episode_005 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.1936 | N | Y | N |
| episode_005 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |

## Hygiene Rows

| episode | budget | policy | metric | value |
|---|---:|---|---|---:|
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_000 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_000 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_000 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_001 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_001 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_001 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_002 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_002 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_002 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_003 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_003 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_003 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_004 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_004 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_004 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_005 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_005 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_005 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |

## Selected Clips

| episode | budget | policy | rank | sample | source | score | quality | artifact | valid |
|---|---:|---|---:|---|---|---:|---:|---:|---|
| episode_000 | 1 | oracle_greedy_target_family_v1 | 1 | worker00959_clip013 | worker00959 | 0.5000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | quality_only_v1 | 1 | worker00908_clip001 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | quality_stratified_random_v1 | 1 | worker00913_clip019 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | submitted_full_replay_v1 | 1 | worker00908_clip012 | worker00908 | 0.7832 | 1.000 | 0.000 | Y |
| episode_000 | 1 | ts2vec_kcenter_v1 | 1 | worker00908_clip012 | worker00908 | 0.9696 | 1.000 | 0.000 | Y |
| episode_000 | 1 | window_kcenter_v1 | 1 | worker01144_clip015 | worker01144 | 9.6707 | 0.999 | 0.000 | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | 1 | worker00959_clip013 | worker00959 | 0.5000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | 2 | worker00913_clip020 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_only_v1 | 1 | worker00908_clip001 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_only_v1 | 2 | worker00908_clip012 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_stratified_random_v1 | 1 | worker00913_clip019 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_stratified_random_v1 | 2 | worker00920_clip014 | worker00920 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | submitted_full_replay_v1 | 1 | worker00908_clip012 | worker00908 | 0.7832 | 1.000 | 0.000 | Y |
| episode_000 | 2 | submitted_full_replay_v1 | 2 | worker01144_clip015 | worker01144 | 0.8390 | 0.999 | 0.000 | Y |
| episode_000 | 2 | ts2vec_kcenter_v1 | 1 | worker00908_clip012 | worker00908 | 0.9696 | 1.000 | 0.000 | Y |
| episode_000 | 2 | ts2vec_kcenter_v1 | 2 | worker01047_clip020 | worker01047 | 0.7972 | 1.000 | 0.000 | Y |
| episode_000 | 2 | window_kcenter_v1 | 1 | worker01144_clip015 | worker01144 | 9.6707 | 0.999 | 0.000 | Y |
| episode_000 | 2 | window_kcenter_v1 | 2 | worker01047_clip012 | worker01047 | 5.9918 | 0.937 | 0.013 | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | 1 | worker00959_clip013 | worker00959 | 0.5000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | 2 | worker00913_clip020 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | 3 | worker01181_clip019 | worker01181 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | 4 | worker01181_clip016 | worker01181 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 1 | worker00908_clip001 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 2 | worker00908_clip012 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 3 | worker00913_clip019 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 4 | worker00913_clip020 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 1 | worker00913_clip019 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 2 | worker00920_clip014 | worker00920 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 3 | worker00913_clip020 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 4 | worker00925_clip008 | worker00925 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 1 | worker00908_clip012 | worker00908 | 0.7832 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 2 | worker01144_clip015 | worker01144 | 0.8390 | 0.999 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 3 | worker01047_clip012 | worker01047 | 0.8702 | 0.937 | 0.013 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 4 | worker00946_clip017 | worker00946 | 0.9549 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 1 | worker00908_clip012 | worker00908 | 0.9696 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 2 | worker01047_clip020 | worker01047 | 0.7972 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 3 | worker00959_clip013 | worker00959 | 0.7437 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 4 | worker00946_clip017 | worker00946 | 0.7158 | 1.000 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 1 | worker01144_clip015 | worker01144 | 9.6707 | 0.999 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 2 | worker01047_clip012 | worker01047 | 5.9918 | 0.937 | 0.013 | Y |
| episode_000 | 4 | window_kcenter_v1 | 3 | worker00908_clip012 | worker00908 | 5.6312 | 1.000 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 4 | worker00946_clip017 | worker00946 | 4.9538 | 1.000 | 0.000 | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | 1 | worker00959_clip013 | worker00959 | 0.5000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | quality_only_v1 | 1 | worker00916_clip008 | worker00916 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | quality_stratified_random_v1 | 1 | worker00916_clip008 | worker00916 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | submitted_full_replay_v1 | 1 | worker00928_clip015 | worker00928 | 0.8031 | 0.971 | 0.006 | Y |
| episode_001 | 1 | ts2vec_kcenter_v1 | 1 | worker00925_clip008 | worker00925 | 0.7942 | 1.000 | 0.000 | Y |
| episode_001 | 1 | window_kcenter_v1 | 1 | worker00928_clip015 | worker00928 | 8.5714 | 0.971 | 0.006 | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | 1 | worker00959_clip013 | worker00959 | 0.5000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | 2 | worker00928_clip011 | worker00928 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_only_v1 | 1 | worker00916_clip008 | worker00916 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_only_v1 | 2 | worker00916_clip016 | worker00916 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_stratified_random_v1 | 1 | worker00916_clip008 | worker00916 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_stratified_random_v1 | 2 | worker00943_clip010 | worker00943 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | submitted_full_replay_v1 | 1 | worker00928_clip015 | worker00928 | 0.8031 | 0.971 | 0.006 | Y |
| episode_001 | 2 | submitted_full_replay_v1 | 2 | worker00959_clip013 | worker00959 | 0.9485 | 1.000 | 0.000 | Y |
| episode_001 | 2 | ts2vec_kcenter_v1 | 1 | worker00925_clip008 | worker00925 | 0.7942 | 1.000 | 0.000 | Y |
| episode_001 | 2 | ts2vec_kcenter_v1 | 2 | worker00959_clip013 | worker00959 | 0.7215 | 1.000 | 0.000 | Y |
| episode_001 | 2 | window_kcenter_v1 | 1 | worker00928_clip015 | worker00928 | 8.5714 | 0.971 | 0.006 | Y |
| episode_001 | 2 | window_kcenter_v1 | 2 | worker00959_clip012 | worker00959 | 5.9003 | 1.000 | 0.000 | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | 1 | worker00959_clip013 | worker00959 | 0.5000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | 2 | worker00928_clip011 | worker00928 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | 3 | worker01149_clip011 | worker01149 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | 4 | worker01149_clip009 | worker01149 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 1 | worker00916_clip008 | worker00916 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 2 | worker00916_clip016 | worker00916 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 3 | worker00925_clip008 | worker00925 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 4 | worker00925_clip018 | worker00925 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 1 | worker00916_clip008 | worker00916 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 2 | worker00943_clip010 | worker00943 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 3 | worker00928_clip011 | worker00928 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 4 | worker00916_clip016 | worker00916 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 1 | worker00928_clip015 | worker00928 | 0.8031 | 0.971 | 0.006 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 2 | worker00959_clip013 | worker00959 | 0.9485 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 3 | worker00925_clip008 | worker00925 | 0.8713 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 4 | worker00945_clip006 | worker00945 | 0.9262 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 1 | worker00925_clip008 | worker00925 | 0.7942 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 2 | worker00959_clip013 | worker00959 | 0.7215 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 3 | worker01111_clip001 | worker01111 | 0.6628 | 0.962 | 0.008 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 4 | worker00945_clip006 | worker00945 | 0.5663 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 1 | worker00928_clip015 | worker00928 | 8.5714 | 0.971 | 0.006 | Y |
| episode_001 | 4 | window_kcenter_v1 | 2 | worker00959_clip012 | worker00959 | 5.9003 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 3 | worker00945_clip006 | worker00945 | 5.5772 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 4 | worker00925_clip008 | worker00925 | 4.1996 | 1.000 | 0.000 | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | 1 | worker00928_clip011 | worker00928 | 0.5000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | quality_only_v1 | 1 | worker00908_clip001 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | quality_stratified_random_v1 | 1 | worker00914_clip018 | worker00914 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | submitted_full_replay_v1 | 1 | worker00913_clip019 | worker00913 | 0.9137 | 1.000 | 0.000 | Y |
| episode_002 | 1 | ts2vec_kcenter_v1 | 1 | worker00913_clip020 | worker00913 | 1.2365 | 1.000 | 0.000 | Y |
| episode_002 | 1 | window_kcenter_v1 | 1 | worker00928_clip012 | worker00928 | 18.3201 | 0.991 | 0.002 | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | 1 | worker00928_clip011 | worker00928 | 0.5000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | 2 | worker00913_clip020 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_only_v1 | 1 | worker00908_clip001 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_only_v1 | 2 | worker00908_clip012 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_stratified_random_v1 | 1 | worker00914_clip018 | worker00914 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_stratified_random_v1 | 2 | worker00913_clip019 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | submitted_full_replay_v1 | 1 | worker00913_clip019 | worker00913 | 0.9137 | 1.000 | 0.000 | Y |
| episode_002 | 2 | submitted_full_replay_v1 | 2 | worker00925_clip008 | worker00925 | 0.9819 | 1.000 | 0.000 | Y |
| episode_002 | 2 | ts2vec_kcenter_v1 | 1 | worker00913_clip020 | worker00913 | 1.2365 | 1.000 | 0.000 | Y |
| episode_002 | 2 | ts2vec_kcenter_v1 | 2 | worker00925_clip008 | worker00925 | 1.0953 | 1.000 | 0.000 | Y |
| episode_002 | 2 | window_kcenter_v1 | 1 | worker00928_clip012 | worker00928 | 18.3201 | 0.991 | 0.002 | Y |
| episode_002 | 2 | window_kcenter_v1 | 2 | worker00925_clip018 | worker00925 | 11.6441 | 1.000 | 0.000 | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | 1 | worker00928_clip011 | worker00928 | 0.5000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | 2 | worker00913_clip020 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | 3 | worker01181_clip019 | worker01181 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | 4 | worker01181_clip016 | worker01181 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 1 | worker00908_clip001 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 2 | worker00908_clip012 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 3 | worker00912_clip006 | worker00912 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 4 | worker00913_clip019 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 1 | worker00914_clip018 | worker00914 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 2 | worker00913_clip019 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 3 | worker00913_clip020 | worker00913 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 4 | worker00908_clip012 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 1 | worker00913_clip019 | worker00913 | 0.9137 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 2 | worker00925_clip008 | worker00925 | 0.9819 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 3 | worker00932_clip003 | worker00932 | 0.8974 | 0.989 | 0.002 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 4 | worker00928_clip015 | worker00928 | 0.8617 | 0.971 | 0.006 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 1 | worker00913_clip020 | worker00913 | 1.2365 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 2 | worker00925_clip008 | worker00925 | 1.0953 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 3 | worker00908_clip001 | worker00908 | 1.0642 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 4 | worker00908_clip020 | worker00908 | 0.9749 | 0.998 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 1 | worker00928_clip012 | worker00928 | 18.3201 | 0.991 | 0.002 | Y |
| episode_002 | 4 | window_kcenter_v1 | 2 | worker00925_clip018 | worker00925 | 11.6441 | 1.000 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 3 | worker00932_clip003 | worker00932 | 10.6081 | 0.989 | 0.002 | Y |
| episode_002 | 4 | window_kcenter_v1 | 4 | worker00908_clip012 | worker00908 | 9.8239 | 1.000 | 0.000 | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | 1 | worker01079_clip019 | worker01079 | 0.5000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | quality_only_v1 | 1 | worker00925_clip008 | worker00925 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | quality_stratified_random_v1 | 1 | worker00969_clip012 | worker00969 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | submitted_full_replay_v1 | 1 | worker01047_clip020 | worker01047 | 0.9153 | 1.000 | 0.000 | Y |
| episode_003 | 1 | ts2vec_kcenter_v1 | 1 | worker00922_clip012 | worker00922 | 0.9213 | 0.998 | 0.000 | Y |
| episode_003 | 1 | window_kcenter_v1 | 1 | worker01047_clip012 | worker01047 | 8.9469 | 0.937 | 0.013 | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | 1 | worker01079_clip019 | worker01079 | 0.5000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | 2 | worker00931_clip016 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_only_v1 | 1 | worker00925_clip008 | worker00925 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_only_v1 | 2 | worker00925_clip018 | worker00925 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_stratified_random_v1 | 1 | worker00969_clip012 | worker00969 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_stratified_random_v1 | 2 | worker00925_clip020 | worker00925 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | submitted_full_replay_v1 | 1 | worker01047_clip020 | worker01047 | 0.9153 | 1.000 | 0.000 | Y |
| episode_003 | 2 | submitted_full_replay_v1 | 2 | worker00922_clip008 | worker00922 | 0.7395 | 0.996 | 0.001 | Y |
| episode_003 | 2 | ts2vec_kcenter_v1 | 1 | worker00922_clip012 | worker00922 | 0.9213 | 0.998 | 0.000 | Y |
| episode_003 | 2 | ts2vec_kcenter_v1 | 2 | worker01047_clip020 | worker01047 | 0.7972 | 1.000 | 0.000 | Y |
| episode_003 | 2 | window_kcenter_v1 | 1 | worker01047_clip012 | worker01047 | 8.9469 | 0.937 | 0.013 | Y |
| episode_003 | 2 | window_kcenter_v1 | 2 | worker01181_clip019 | worker01181 | 6.0365 | 1.000 | 0.000 | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | 1 | worker01079_clip019 | worker01079 | 0.5000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | 2 | worker00931_clip016 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | 3 | worker01181_clip019 | worker01181 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | 4 | worker01181_clip016 | worker01181 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 1 | worker00925_clip008 | worker00925 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 2 | worker00925_clip018 | worker00925 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 3 | worker00925_clip020 | worker00925 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 4 | worker00931_clip002 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 1 | worker00969_clip012 | worker00969 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 2 | worker00925_clip020 | worker00925 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 3 | worker00969_clip007 | worker00969 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 4 | worker00925_clip018 | worker00925 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 1 | worker01047_clip020 | worker01047 | 0.9153 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 2 | worker00922_clip008 | worker00922 | 0.7395 | 0.996 | 0.001 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 3 | worker00969_clip014 | worker00969 | 0.9085 | 0.999 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 4 | worker01047_clip012 | worker01047 | 0.8789 | 0.937 | 0.013 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 1 | worker00922_clip012 | worker00922 | 0.9213 | 0.998 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 2 | worker01047_clip020 | worker01047 | 0.7972 | 1.000 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 3 | worker00969_clip014 | worker00969 | 0.6176 | 0.999 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 4 | worker00922_clip019 | worker00922 | 0.5604 | 0.987 | 0.003 | Y |
| episode_003 | 4 | window_kcenter_v1 | 1 | worker01047_clip012 | worker01047 | 8.9469 | 0.937 | 0.013 | Y |
| episode_003 | 4 | window_kcenter_v1 | 2 | worker01181_clip019 | worker01181 | 6.0365 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 3 | worker01047_clip020 | worker01047 | 3.6577 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 4 | worker01053_clip007 | worker01053 | 2.7439 | 0.992 | 0.002 | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | 1 | worker01079_clip019 | worker01079 | 0.5000 | 1.000 | 0.000 | Y |
| episode_004 | 1 | quality_only_v1 | 1 | worker00907_clip010 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 1 | quality_stratified_random_v1 | 1 | worker00908_clip012 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 1 | submitted_full_replay_v1 | 1 | worker01047_clip012 | worker01047 | 1.0000 | 0.937 | 0.013 | Y |
| episode_004 | 1 | ts2vec_kcenter_v1 | 1 | worker01047_clip012 | worker01047 | 0.7017 | 0.937 | 0.013 | Y |
| episode_004 | 1 | window_kcenter_v1 | 1 | worker01047_clip012 | worker01047 | 6.1016 | 0.937 | 0.013 | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | 1 | worker01079_clip019 | worker01079 | 0.5000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | 2 | worker00985_clip001 | worker00985 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | quality_only_v1 | 1 | worker00907_clip010 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | quality_only_v1 | 2 | worker00907_clip017 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | quality_stratified_random_v1 | 1 | worker00908_clip012 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | quality_stratified_random_v1 | 2 | worker00907_clip010 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | submitted_full_replay_v1 | 1 | worker01047_clip012 | worker01047 | 1.0000 | 0.937 | 0.013 | Y |
| episode_004 | 2 | submitted_full_replay_v1 | 2 | worker00983_clip007 | worker00983 | 0.8378 | 0.990 | 0.002 | Y |
| episode_004 | 2 | ts2vec_kcenter_v1 | 1 | worker01047_clip012 | worker01047 | 0.7017 | 0.937 | 0.013 | Y |
| episode_004 | 2 | ts2vec_kcenter_v1 | 2 | worker00939_clip016 | worker00939 | 0.6628 | 1.000 | 0.000 | Y |
| episode_004 | 2 | window_kcenter_v1 | 1 | worker01047_clip012 | worker01047 | 6.1016 | 0.937 | 0.013 | Y |
| episode_004 | 2 | window_kcenter_v1 | 2 | worker00983_clip007 | worker00983 | 5.5281 | 0.990 | 0.002 | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | 1 | worker01079_clip019 | worker01079 | 0.5000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | 2 | worker00985_clip001 | worker00985 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | 3 | worker01181_clip019 | worker01181 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | 4 | worker01181_clip016 | worker01181 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_only_v1 | 1 | worker00907_clip010 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_only_v1 | 2 | worker00907_clip017 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_only_v1 | 3 | worker00907_clip020 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_only_v1 | 4 | worker00908_clip001 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_stratified_random_v1 | 1 | worker00908_clip012 | worker00908 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_stratified_random_v1 | 2 | worker00907_clip010 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_stratified_random_v1 | 3 | worker00907_clip017 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_stratified_random_v1 | 4 | worker00939_clip005 | worker00939 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | submitted_full_replay_v1 | 1 | worker01047_clip012 | worker01047 | 1.0000 | 0.937 | 0.013 | Y |
| episode_004 | 4 | submitted_full_replay_v1 | 2 | worker00983_clip007 | worker00983 | 0.8378 | 0.990 | 0.002 | Y |
| episode_004 | 4 | submitted_full_replay_v1 | 3 | worker01047_clip020 | worker01047 | 0.7899 | 1.000 | 0.000 | Y |
| episode_004 | 4 | submitted_full_replay_v1 | 4 | worker00939_clip016 | worker00939 | 0.8019 | 1.000 | 0.000 | Y |
| episode_004 | 4 | ts2vec_kcenter_v1 | 1 | worker01047_clip012 | worker01047 | 0.7017 | 0.937 | 0.013 | Y |
| episode_004 | 4 | ts2vec_kcenter_v1 | 2 | worker00939_clip016 | worker00939 | 0.6628 | 1.000 | 0.000 | Y |
| episode_004 | 4 | ts2vec_kcenter_v1 | 3 | worker00908_clip012 | worker00908 | 0.5280 | 1.000 | 0.000 | Y |
| episode_004 | 4 | ts2vec_kcenter_v1 | 4 | worker01002_clip018 | worker01002 | 0.4868 | 0.994 | 0.001 | Y |
| episode_004 | 4 | window_kcenter_v1 | 1 | worker01047_clip012 | worker01047 | 6.1016 | 0.937 | 0.013 | Y |
| episode_004 | 4 | window_kcenter_v1 | 2 | worker00983_clip007 | worker00983 | 5.5281 | 0.990 | 0.002 | Y |
| episode_004 | 4 | window_kcenter_v1 | 3 | worker01047_clip020 | worker01047 | 3.7694 | 1.000 | 0.000 | Y |
| episode_004 | 4 | window_kcenter_v1 | 4 | worker00969_clip014 | worker00969 | 3.0873 | 0.999 | 0.000 | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | 1 | worker00985_clip001 | worker00985 | 0.5000 | 1.000 | 0.000 | Y |
| episode_005 | 1 | quality_only_v1 | 1 | worker00931_clip002 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 1 | quality_stratified_random_v1 | 1 | worker00931_clip016 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 1 | submitted_full_replay_v1 | 1 | worker00983_clip007 | worker00983 | 0.8041 | 0.990 | 0.002 | Y |
| episode_005 | 1 | ts2vec_kcenter_v1 | 1 | worker00922_clip012 | worker00922 | 1.1959 | 0.998 | 0.000 | Y |
| episode_005 | 1 | window_kcenter_v1 | 1 | worker00983_clip007 | worker00983 | 9.7768 | 0.990 | 0.002 | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | 1 | worker00985_clip001 | worker00985 | 0.5000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | 2 | worker00931_clip016 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | quality_only_v1 | 1 | worker00931_clip002 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | quality_only_v1 | 2 | worker00931_clip015 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | quality_stratified_random_v1 | 1 | worker00931_clip016 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | quality_stratified_random_v1 | 2 | worker00946_clip004 | worker00946 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | submitted_full_replay_v1 | 1 | worker00983_clip007 | worker00983 | 0.8041 | 0.990 | 0.002 | Y |
| episode_005 | 2 | submitted_full_replay_v1 | 2 | worker00983_clip017 | worker00983 | 0.8289 | 0.999 | 0.000 | Y |
| episode_005 | 2 | ts2vec_kcenter_v1 | 1 | worker00922_clip012 | worker00922 | 1.1959 | 0.998 | 0.000 | Y |
| episode_005 | 2 | ts2vec_kcenter_v1 | 2 | worker00983_clip017 | worker00983 | 1.1663 | 0.999 | 0.000 | Y |
| episode_005 | 2 | window_kcenter_v1 | 1 | worker00983_clip007 | worker00983 | 9.7768 | 0.990 | 0.002 | Y |
| episode_005 | 2 | window_kcenter_v1 | 2 | worker01047_clip012 | worker01047 | 7.9203 | 0.937 | 0.013 | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | 1 | worker00985_clip001 | worker00985 | 0.5000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | 2 | worker00931_clip016 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | 3 | worker01181_clip019 | worker01181 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | 4 | worker01181_clip016 | worker01181 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_only_v1 | 1 | worker00931_clip002 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_only_v1 | 2 | worker00931_clip015 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_only_v1 | 3 | worker00931_clip016 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_only_v1 | 4 | worker00946_clip004 | worker00946 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_stratified_random_v1 | 1 | worker00931_clip016 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_stratified_random_v1 | 2 | worker00946_clip004 | worker00946 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_stratified_random_v1 | 3 | worker00969_clip012 | worker00969 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_stratified_random_v1 | 4 | worker00931_clip002 | worker00931 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | submitted_full_replay_v1 | 1 | worker00983_clip007 | worker00983 | 0.8041 | 0.990 | 0.002 | Y |
| episode_005 | 4 | submitted_full_replay_v1 | 2 | worker00983_clip017 | worker00983 | 0.8289 | 0.999 | 0.000 | Y |
| episode_005 | 4 | submitted_full_replay_v1 | 3 | worker01047_clip020 | worker01047 | 0.8143 | 1.000 | 0.000 | Y |
| episode_005 | 4 | submitted_full_replay_v1 | 4 | worker00922_clip008 | worker00922 | 0.8496 | 0.996 | 0.001 | Y |
| episode_005 | 4 | ts2vec_kcenter_v1 | 1 | worker00922_clip012 | worker00922 | 1.1959 | 0.998 | 0.000 | Y |
| episode_005 | 4 | ts2vec_kcenter_v1 | 2 | worker00983_clip017 | worker00983 | 1.1663 | 0.999 | 0.000 | Y |
| episode_005 | 4 | ts2vec_kcenter_v1 | 3 | worker00985_clip004 | worker00985 | 0.8867 | 0.999 | 0.000 | Y |
| episode_005 | 4 | ts2vec_kcenter_v1 | 4 | worker01047_clip020 | worker01047 | 0.7926 | 1.000 | 0.000 | Y |
| episode_005 | 4 | window_kcenter_v1 | 1 | worker00983_clip007 | worker00983 | 9.7768 | 0.990 | 0.002 | Y |
| episode_005 | 4 | window_kcenter_v1 | 2 | worker01047_clip012 | worker01047 | 7.9203 | 0.937 | 0.013 | Y |
| episode_005 | 4 | window_kcenter_v1 | 3 | worker01181_clip019 | worker01181 | 6.0365 | 1.000 | 0.000 | Y |
| episode_005 | 4 | window_kcenter_v1 | 4 | worker00985_clip001 | worker00985 | 5.7512 | 1.000 | 0.000 | Y |

## Decision Notes

- Primary rows exclude same-feature-family selector/eval comparisons.
- Oracle rows, when present, are diagnostics because they inspect the target set.
- Deployable v1 policies only select candidates that pass quality and artifact gates.
