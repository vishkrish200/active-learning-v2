# Downstream Coverage Supervised Smoke

This is a source-family pseudo-label frozen-feature supervised probe, not real challenge-label downstream proof.

## Decision

- downstream training: `hold_large_training`
- read: source-family pseudo-label bridge downstream benchmark ran with predeclared frozen model heads; keep this as an identifiability gate and do not treat it as real challenge-label downstream proof.
- top policy: `window_kcenter_v1`
- baseline policy: `quality_stratified_random_v1`
- target-family discovery delta vs baseline: `0.333333`
- balanced accuracy delta vs baseline: `-0.034722`
- NLL delta vs baseline: `4.824102`

## Run

- episodes: `6`
- budgets: `0, 1, 2, 4`
- downstream representations: `window, raw_shape_stats`
- downstream model heads: `nearest_centroid, ridge_classifier`

## Budget Means

| policy | budget | discovery rate | bridge clips | balanced accuracy gain | NLL reduction | after known target frac | rows |
|---|---:|---:|---:|---:|---:|---:|---:|
| oracle_greedy_target_family_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| oracle_greedy_target_family_v1 | 1 | 0.500000 | 1.000000 | 0.199074 | 11.545200 | 0.500000 | 24 |
| oracle_greedy_target_family_v1 | 2 | 1.000000 | 2.000000 | 0.298611 | 21.703360 | 1.000000 | 24 |
| oracle_greedy_target_family_v1 | 4 | 1.000000 | 2.000000 | 0.280093 | 21.598125 | 1.000000 | 24 |
| quality_only_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| quality_only_v1 | 1 | 0.250000 | 0.500000 | 0.108796 | 5.506225 | 0.250000 | 24 |
| quality_only_v1 | 2 | 0.250000 | 1.000000 | 0.097222 | 5.493020 | 0.250000 | 24 |
| quality_only_v1 | 4 | 0.416667 | 2.166667 | 0.157407 | 9.437927 | 0.416667 | 24 |
| quality_stratified_random_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| quality_stratified_random_v1 | 1 | 0.166667 | 0.333333 | 0.053241 | 3.772114 | 0.166667 | 24 |
| quality_stratified_random_v1 | 2 | 0.250000 | 0.500000 | 0.122685 | 5.681019 | 0.250000 | 24 |
| quality_stratified_random_v1 | 4 | 0.333333 | 1.333333 | 0.131944 | 7.098817 | 0.333333 | 24 |
| submitted_full_replay_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| submitted_full_replay_v1 | 1 | 0.333333 | 0.666667 | 0.074074 | 5.820278 | 0.333333 | 24 |
| submitted_full_replay_v1 | 2 | 0.666667 | 1.500000 | 0.145833 | 12.693760 | 0.666667 | 24 |
| submitted_full_replay_v1 | 4 | 0.833333 | 2.166667 | 0.150463 | 15.419542 | 0.833333 | 24 |
| ts2vec_kcenter_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| ts2vec_kcenter_v1 | 1 | 0.416667 | 0.833333 | 0.120370 | 8.897675 | 0.416667 | 24 |
| ts2vec_kcenter_v1 | 2 | 0.666667 | 1.333333 | 0.171296 | 13.795972 | 0.666667 | 24 |
| ts2vec_kcenter_v1 | 4 | 0.750000 | 2.333333 | 0.178241 | 15.345646 | 0.750000 | 24 |
| window_kcenter_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| window_kcenter_v1 | 1 | 0.250000 | 0.500000 | 0.046296 | 4.093172 | 0.250000 | 24 |
| window_kcenter_v1 | 2 | 0.416667 | 1.000000 | 0.099537 | 7.269800 | 0.416667 | 24 |
| window_kcenter_v1 | 4 | 0.666667 | 1.833333 | 0.097222 | 11.922918 | 0.666667 | 24 |

## Caveat

- Budget `0` is the support-only baseline. Later budgets add selected candidate clips to support before evaluating the pseudo-label probe.
- This checks whether acquisition changes a tiny downstream classifier/probe; it is still not a learned query policy or TS2Vec retraining proof.
