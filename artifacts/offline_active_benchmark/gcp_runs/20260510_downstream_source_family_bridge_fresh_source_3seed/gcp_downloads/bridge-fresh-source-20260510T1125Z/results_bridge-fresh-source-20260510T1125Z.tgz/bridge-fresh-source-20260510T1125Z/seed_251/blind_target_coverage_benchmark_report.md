# Blind Target Coverage Benchmark

## Run

- episodes: `6`
- policies: `quality_stratified_random_v1, quality_only_v1, window_kcenter_v1, submitted_full_replay_v1, ts2vec_kcenter_v1, oracle_greedy_target_family_v1`
- budgets: `1, 2, 4`
- eval views: `ts2vec, window, raw_shape_stats`
- primary eval views: `window, raw_shape_stats`
- distance metric: `euclidean`

## Policy Summary

| policy | mean primary coverage_gain_rel | primary rows | diagnostic rows | underfilled rounds |
|---|---:|---:|---:|---:|
| oracle_greedy_target_family_v1 | 0.0000 | 0 | 54 | 0 |
| quality_only_v1 | 0.0020 | 36 | 18 | 0 |
| quality_stratified_random_v1 | 0.0084 | 36 | 18 | 0 |
| submitted_full_replay_v1 | 0.0568 | 18 | 36 | 0 |
| ts2vec_kcenter_v1 | 0.0304 | 36 | 18 | 0 |
| window_kcenter_v1 | 0.1163 | 18 | 36 | 0 |

## Coverage Rows

| episode | budget | policy | eval view | metric | value | primary | feature overlap | target-used |
|---|---:|---|---|---|---:|---|---|---|
| episode_000 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 6.7286 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1621 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0855 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.1607 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.9299 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1690 | N | N | Y |
| episode_000 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.2778 | N | N | Y |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0685 | N | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0867 | N | N | N |
| episode_000 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | N |
| episode_000 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0168 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0017 | Y | N | N |
| episode_000 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0685 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0867 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0168 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0017 | Y | N | N |
| episode_000 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0685 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0867 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0177 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0018 | N | Y | N |
| episode_000 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.5214 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0391 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0078 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0147 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0639 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0284 | Y | N | N |
| episode_000 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 10.6325 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1150 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0746 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0944 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | N |
| episode_000 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.7399 | N | Y | N |
| episode_000 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0739 | N | Y | N |
| episode_000 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 6.8511 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1729 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0855 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.1607 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.9299 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1690 | N | N | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.2778 | N | N | Y |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0685 | N | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0867 | N | N | N |
| episode_000 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | N |
| episode_000 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0170 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0017 | Y | N | N |
| episode_000 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0685 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0867 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0170 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0017 | Y | N | N |
| episode_000 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 4.8877 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.1166 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0685 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0867 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.1619 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0258 | N | Y | N |
| episode_000 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.5214 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0391 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0078 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0147 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0639 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0284 | Y | N | N |
| episode_000 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 17.3611 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2771 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1601 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.2550 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.3889 | N | N | N |
| episode_000 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 1.6698 | N | Y | N |
| episode_000 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.2429 | N | Y | N |
| episode_000 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.2778 | N | Y | N |
| episode_000 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 6.8511 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1729 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0855 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.1607 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.9299 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1690 | N | N | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.2778 | N | N | Y |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.1225 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0108 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0685 | N | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0867 | N | N | N |
| episode_000 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | N |
| episode_000 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0177 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0018 | Y | N | N |
| episode_000 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 2.9936 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0867 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0685 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0867 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0170 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0017 | Y | N | N |
| episode_000 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 7.2458 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2011 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.1619 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.2621 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 1.0113 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1992 | N | Y | N |
| episode_000 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.2778 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 5.4092 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1557 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0763 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1014 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.2251 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0542 | Y | N | N |
| episode_000 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 17.3611 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2771 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1601 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.2550 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.3889 | N | N | N |
| episode_000 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 1.6698 | N | Y | N |
| episode_000 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.2429 | N | Y | N |
| episode_000 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.2778 | N | Y | N |
| episode_001 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 1.2360 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1318 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0384 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0838 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.1111 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2846 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1115 | N | N | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1111 | N | N | Y |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0473 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0011 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0006 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0006 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 1.2360 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1318 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0384 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0838 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.1111 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2846 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1115 | N | N | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1111 | N | N | Y |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0473 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0011 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0006 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0006 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0473 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0011 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0006 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0006 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0473 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0011 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0006 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0006 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 1.2360 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1318 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0384 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0838 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.1111 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2846 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1115 | N | N | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1111 | N | N | Y |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0149 | N | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0280 | N | N | N |
| episode_001 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0268 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0059 | Y | N | N |
| episode_001 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0150 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0281 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0268 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0059 | Y | N | N |
| episode_001 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0473 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0011 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0006 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0006 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_001 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0473 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0011 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0006 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0006 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_001 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0473 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0011 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0155 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0287 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_001 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.0268 | N | Y | N |
| episode_001 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0059 | N | Y | N |
| episode_001 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 6.7286 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1621 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0855 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.1607 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.9299 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1690 | N | N | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.2778 | N | N | Y |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0685 | N | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0867 | N | N | N |
| episode_002 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | N |
| episode_002 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0168 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0017 | Y | N | N |
| episode_002 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0685 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0867 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0177 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0018 | N | Y | N |
| episode_002 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.5214 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0391 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0078 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0147 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0639 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0284 | Y | N | N |
| episode_002 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 10.6325 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1150 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0746 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0944 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | N |
| episode_002 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.7399 | N | Y | N |
| episode_002 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0739 | N | Y | N |
| episode_002 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 6.8511 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1729 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0855 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.1607 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.9299 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1690 | N | N | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.2778 | N | N | Y |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0685 | N | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0867 | N | N | N |
| episode_002 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | N |
| episode_002 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0170 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0017 | Y | N | N |
| episode_002 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 4.8877 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.1166 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0685 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0867 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.1619 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0258 | N | Y | N |
| episode_002 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.5214 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0391 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0078 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0147 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0556 | N | Y | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0639 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0284 | Y | N | N |
| episode_002 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 17.3611 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2771 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1601 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.2550 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.3889 | N | N | N |
| episode_002 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 1.6698 | N | Y | N |
| episode_002 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.2429 | N | Y | N |
| episode_002 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.2778 | N | Y | N |
| episode_002 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 6.8511 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1729 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0855 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.1607 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.9299 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1690 | N | N | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.2778 | N | N | Y |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.1225 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0108 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0685 | N | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0867 | N | N | N |
| episode_002 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.1667 | N | N | N |
| episode_002 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0177 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0018 | Y | N | N |
| episode_002 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 2.9936 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0867 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_002 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 7.2458 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.2011 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.1619 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.2621 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.4444 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 1.0113 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.1992 | N | Y | N |
| episode_002 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.2778 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 5.4092 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1557 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0763 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.1014 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.2222 | N | Y | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.2251 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0542 | Y | N | N |
| episode_002 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 17.3611 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.2771 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.1601 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.2550 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.3889 | N | N | N |
| episode_002 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 1.6698 | N | Y | N |
| episode_002 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.2429 | N | Y | N |
| episode_002 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.2778 | N | Y | N |
| episode_003 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 1.2360 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1318 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0384 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0838 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.1111 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2846 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1115 | N | N | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1111 | N | N | Y |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0149 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0280 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0268 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0059 | Y | N | N |
| episode_003 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0473 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0011 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0006 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0006 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 1.2360 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1318 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0384 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0838 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.1111 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2846 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1115 | N | N | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1111 | N | N | Y |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0149 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0280 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0268 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0059 | Y | N | N |
| episode_003 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0473 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0011 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0006 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0006 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0473 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0011 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0006 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0006 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0473 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0011 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0006 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0006 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 1.2360 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1318 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0384 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0838 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.1111 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2846 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.1115 | N | N | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.1111 | N | N | Y |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0149 | N | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0280 | N | N | N |
| episode_003 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0268 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0059 | Y | N | N |
| episode_003 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0149 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0280 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0268 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0059 | Y | N | N |
| episode_003 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0473 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0011 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0006 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0006 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_003 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0473 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0011 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0006 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0006 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_003 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0473 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0011 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0155 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0287 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_003 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.0268 | N | Y | N |
| episode_003 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0059 | N | Y | N |
| episode_003 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 7.6642 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1850 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0043 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0068 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2440 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0424 | N | N | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_004 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 7.6642 | Y | N | N |
| episode_004 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1850 | Y | N | N |
| episode_004 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_004 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0043 | N | N | N |
| episode_004 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0068 | N | N | N |
| episode_004 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.2440 | N | Y | N |
| episode_004 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0424 | N | Y | N |
| episode_004 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 7.6642 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1850 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0043 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0068 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2440 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0424 | N | N | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_004 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 7.6642 | Y | N | N |
| episode_004 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1850 | Y | N | N |
| episode_004 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_004 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0043 | N | N | N |
| episode_004 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0068 | N | N | N |
| episode_004 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.2440 | N | Y | N |
| episode_004 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0424 | N | Y | N |
| episode_004 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 7.6642 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.1850 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0043 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0068 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.2440 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0424 | N | N | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_004 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 3.4215 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0832 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 7.6642 | Y | N | N |
| episode_004 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.1850 | Y | N | N |
| episode_004 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_004 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0043 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0068 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.2440 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0424 | N | Y | N |
| episode_004 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 0.3860 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0332 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_004 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_004 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 7.6642 | Y | N | N |
| episode_004 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.1850 | Y | N | N |
| episode_004 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.1667 | Y | N | N |
| episode_004 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0043 | N | N | N |
| episode_004 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0068 | N | N | N |
| episode_004 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_004 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.2440 | N | Y | N |
| episode_004 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0424 | N | Y | N |
| episode_004 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0013 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0033 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_005 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0007 | N | N | N |
| episode_005 | 1 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0020 | N | N | N |
| episode_005 | 1 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 1 | quality_only_v1 | window | coverage_gain_abs | 0.0105 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | window | coverage_gain_rel | 0.0090 | Y | N | N |
| episode_005 | 1 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 1 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 2.8591 | Y | N | N |
| episode_005 | 1 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0652 | Y | N | N |
| episode_005 | 1 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.4712 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0567 | N | Y | N |
| episode_005 | 1 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.8591 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0652 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.4712 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0567 | Y | N | N |
| episode_005 | 1 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.8591 | Y | N | N |
| episode_005 | 1 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0652 | Y | N | N |
| episode_005 | 1 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_005 | 1 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_005 | 1 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 1 | window_kcenter_v1 | window | coverage_gain_abs | 0.4712 | N | Y | N |
| episode_005 | 1 | window_kcenter_v1 | window | coverage_gain_rel | 0.0567 | N | Y | N |
| episode_005 | 1 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0013 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0033 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_005 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0007 | N | N | N |
| episode_005 | 2 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0020 | N | N | N |
| episode_005 | 2 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 2 | quality_only_v1 | window | coverage_gain_abs | 0.0105 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | window | coverage_gain_rel | 0.0090 | Y | N | N |
| episode_005 | 2 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0007 | N | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0020 | N | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0105 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0090 | Y | N | N |
| episode_005 | 2 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 2.8591 | Y | N | N |
| episode_005 | 2 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0652 | Y | N | N |
| episode_005 | 2 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.4712 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0567 | N | Y | N |
| episode_005 | 2 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.8591 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0652 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.4712 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0567 | Y | N | N |
| episode_005 | 2 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.8591 | Y | N | N |
| episode_005 | 2 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0652 | Y | N | N |
| episode_005 | 2 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_005 | 2 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_005 | 2 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 2 | window_kcenter_v1 | window | coverage_gain_abs | 0.4712 | N | Y | N |
| episode_005 | 2 | window_kcenter_v1 | window | coverage_gain_rel | 0.0567 | N | Y | N |
| episode_005 | 2 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_abs | 0.0013 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | ts2vec | coverage_gain_rel | 0.0033 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_abs | 0.0000 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | window | coverage_gain_rel | 0.0000 | N | N | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | window | tau_coverage_gain | 0.0000 | N | N | Y |
| episode_005 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | ts2vec | coverage_gain_abs | 0.0007 | N | N | N |
| episode_005 | 4 | quality_only_v1 | ts2vec | coverage_gain_rel | 0.0020 | N | N | N |
| episode_005 | 4 | quality_only_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 4 | quality_only_v1 | window | coverage_gain_abs | 0.0105 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | window | coverage_gain_rel | 0.0090 | Y | N | N |
| episode_005 | 4 | quality_only_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_abs | 0.0000 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | raw_shape_stats | coverage_gain_rel | 0.0000 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_abs | 0.0007 | N | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | ts2vec | coverage_gain_rel | 0.0020 | N | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | window | coverage_gain_abs | 0.0105 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | window | coverage_gain_rel | 0.0090 | Y | N | N |
| episode_005 | 4 | quality_stratified_random_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_abs | 2.8591 | Y | N | N |
| episode_005 | 4 | submitted_full_replay_v1 | raw_shape_stats | coverage_gain_rel | 0.0652 | Y | N | N |
| episode_005 | 4 | submitted_full_replay_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | window | coverage_gain_abs | 0.4712 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | window | coverage_gain_rel | 0.0567 | N | Y | N |
| episode_005 | 4 | submitted_full_replay_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.8591 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0652 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | Y | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | Y | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | Y | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_abs | 0.4712 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | window | coverage_gain_rel | 0.0567 | Y | N | N |
| episode_005 | 4 | ts2vec_kcenter_v1 | window | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_abs | 2.8591 | Y | N | N |
| episode_005 | 4 | window_kcenter_v1 | raw_shape_stats | coverage_gain_rel | 0.0652 | Y | N | N |
| episode_005 | 4 | window_kcenter_v1 | raw_shape_stats | tau_coverage_gain | 0.0000 | Y | N | N |
| episode_005 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_abs | 0.0000 | N | N | N |
| episode_005 | 4 | window_kcenter_v1 | ts2vec | coverage_gain_rel | 0.0000 | N | N | N |
| episode_005 | 4 | window_kcenter_v1 | ts2vec | tau_coverage_gain | 0.0000 | N | N | N |
| episode_005 | 4 | window_kcenter_v1 | window | coverage_gain_abs | 0.4712 | N | Y | N |
| episode_005 | 4 | window_kcenter_v1 | window | coverage_gain_rel | 0.0567 | N | Y | N |
| episode_005 | 4 | window_kcenter_v1 | window | tau_coverage_gain | 0.0000 | N | Y | N |

## Hygiene Rows

| episode | budget | policy | metric | value |
|---|---:|---|---|---:|
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_000 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_000 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_000 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_000 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_001 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_001 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_001 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_001 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_002 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_002 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_002 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_002 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_003 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_003 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_003 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_003 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_004 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_004 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_004 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_004 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_count | 1.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | quality_only_v1 | selected_count | 1.0000 |
| episode_005 | 1 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_count | 1.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_count | 1.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_count | 1.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_count | 1.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 1 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_count | 2.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | quality_only_v1 | selected_count | 2.0000 |
| episode_005 | 2 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_count | 2.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_count | 2.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_count | 2.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_count | 2.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 2 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_count | 4.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | oracle_greedy_target_family_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | quality_only_v1 | selected_count | 4.0000 |
| episode_005 | 4 | quality_only_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | quality_only_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | quality_only_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | quality_only_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_count | 4.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | quality_stratified_random_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_count | 4.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | submitted_full_replay_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_count | 4.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | ts2vec_kcenter_v1 | selected_target_leak_count | 0.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_count | 4.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_duplicate_clip_count | 0.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_invalid_rate | 0.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_out_of_pool_count | 0.0000 |
| episode_005 | 4 | window_kcenter_v1 | selected_target_leak_count | 0.0000 |

## Selected Clips

| episode | budget | policy | rank | sample | source | score | quality | artifact | valid |
|---|---:|---|---:|---|---|---:|---:|---:|---|
| episode_000 | 1 | oracle_greedy_target_family_v1 | 1 | worker01063_clip016 | worker01063 | 0.5000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | quality_only_v1 | 1 | worker00907_clip007 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | quality_stratified_random_v1 | 1 | worker00907_clip007 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 1 | submitted_full_replay_v1 | 1 | worker00907_clip016 | worker00907 | 0.9244 | 1.000 | 0.000 | Y |
| episode_000 | 1 | ts2vec_kcenter_v1 | 1 | worker01102_clip004 | worker01102 | 0.7195 | 0.994 | 0.001 | Y |
| episode_000 | 1 | window_kcenter_v1 | 1 | worker01035_clip014 | worker01035 | 5.6128 | 0.977 | 0.005 | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | 1 | worker01063_clip016 | worker01063 | 0.5000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | oracle_greedy_target_family_v1 | 2 | worker00918_clip013 | worker00918 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_only_v1 | 1 | worker00907_clip007 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_only_v1 | 2 | worker00907_clip010 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_stratified_random_v1 | 1 | worker00907_clip007 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | quality_stratified_random_v1 | 2 | worker00907_clip010 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 2 | submitted_full_replay_v1 | 1 | worker00907_clip016 | worker00907 | 0.9244 | 1.000 | 0.000 | Y |
| episode_000 | 2 | submitted_full_replay_v1 | 2 | worker00918_clip004 | worker00918 | 0.8368 | 0.995 | 0.001 | Y |
| episode_000 | 2 | ts2vec_kcenter_v1 | 1 | worker01102_clip004 | worker01102 | 0.7195 | 0.994 | 0.001 | Y |
| episode_000 | 2 | ts2vec_kcenter_v1 | 2 | worker01092_clip002 | worker01092 | 0.7150 | 1.000 | 0.000 | Y |
| episode_000 | 2 | window_kcenter_v1 | 1 | worker01035_clip014 | worker01035 | 5.6128 | 0.977 | 0.005 | Y |
| episode_000 | 2 | window_kcenter_v1 | 2 | worker01063_clip016 | worker01063 | 5.2344 | 1.000 | 0.000 | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | 1 | worker01063_clip016 | worker01063 | 0.5000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | 2 | worker00918_clip013 | worker00918 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | 3 | worker01125_clip015 | worker01125 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | oracle_greedy_target_family_v1 | 4 | worker01125_clip004 | worker01125 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 1 | worker00907_clip007 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 2 | worker00907_clip010 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 3 | worker00907_clip016 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_only_v1 | 4 | worker00918_clip013 | worker00918 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 1 | worker00907_clip007 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 2 | worker00907_clip010 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 3 | worker00918_clip013 | worker00918 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | quality_stratified_random_v1 | 4 | worker01021_clip004 | worker01021 | 1.0000 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 1 | worker00907_clip016 | worker00907 | 0.9244 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 2 | worker00918_clip004 | worker00918 | 0.8368 | 0.995 | 0.001 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 3 | worker01063_clip015 | worker01063 | 0.8297 | 1.000 | 0.000 | Y |
| episode_000 | 4 | submitted_full_replay_v1 | 4 | worker01102_clip004 | worker01102 | 0.6737 | 0.994 | 0.001 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 1 | worker01102_clip004 | worker01102 | 0.7195 | 0.994 | 0.001 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 2 | worker01092_clip002 | worker01092 | 0.7150 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 3 | worker00907_clip010 | worker00907 | 0.6661 | 1.000 | 0.000 | Y |
| episode_000 | 4 | ts2vec_kcenter_v1 | 4 | worker00918_clip004 | worker00918 | 0.6252 | 0.995 | 0.001 | Y |
| episode_000 | 4 | window_kcenter_v1 | 1 | worker01035_clip014 | worker01035 | 5.6128 | 0.977 | 0.005 | Y |
| episode_000 | 4 | window_kcenter_v1 | 2 | worker01063_clip016 | worker01063 | 5.2344 | 1.000 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 3 | worker00907_clip016 | worker00907 | 5.2057 | 1.000 | 0.000 | Y |
| episode_000 | 4 | window_kcenter_v1 | 4 | worker00918_clip004 | worker00918 | 4.5199 | 0.995 | 0.001 | Y |
| episode_001 | 1 | oracle_greedy_target_family_v1 | 1 | worker01010_clip010 | worker01010 | 0.5000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | quality_only_v1 | 1 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | quality_stratified_random_v1 | 1 | worker00955_clip006 | worker00955 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 1 | submitted_full_replay_v1 | 1 | worker01005_clip015 | worker01005 | 0.8087 | 1.000 | 0.000 | Y |
| episode_001 | 1 | ts2vec_kcenter_v1 | 1 | worker01073_clip008 | worker01073 | 0.7730 | 1.000 | 0.000 | Y |
| episode_001 | 1 | window_kcenter_v1 | 1 | worker00955_clip017 | worker00955 | 5.2065 | 1.000 | 0.000 | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | 1 | worker01010_clip010 | worker01010 | 0.5000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | oracle_greedy_target_family_v1 | 2 | worker00937_clip017 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_only_v1 | 1 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_only_v1 | 2 | worker00937_clip002 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_stratified_random_v1 | 1 | worker00955_clip006 | worker00955 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | quality_stratified_random_v1 | 2 | worker00937_clip017 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 2 | submitted_full_replay_v1 | 1 | worker01005_clip015 | worker01005 | 0.8087 | 1.000 | 0.000 | Y |
| episode_001 | 2 | submitted_full_replay_v1 | 2 | worker00955_clip017 | worker00955 | 0.6501 | 1.000 | 0.000 | Y |
| episode_001 | 2 | ts2vec_kcenter_v1 | 1 | worker01073_clip008 | worker01073 | 0.7730 | 1.000 | 0.000 | Y |
| episode_001 | 2 | ts2vec_kcenter_v1 | 2 | worker01005_clip015 | worker01005 | 0.5867 | 1.000 | 0.000 | Y |
| episode_001 | 2 | window_kcenter_v1 | 1 | worker00955_clip017 | worker00955 | 5.2065 | 1.000 | 0.000 | Y |
| episode_001 | 2 | window_kcenter_v1 | 2 | worker01005_clip015 | worker01005 | 4.8046 | 1.000 | 0.000 | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | 1 | worker01010_clip010 | worker01010 | 0.5000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | 2 | worker00937_clip017 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | 3 | worker01073_clip008 | worker01073 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | oracle_greedy_target_family_v1 | 4 | worker01021_clip011 | worker01021 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 1 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 2 | worker00937_clip002 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 3 | worker00937_clip017 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_only_v1 | 4 | worker00953_clip007 | worker00953 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 1 | worker00955_clip006 | worker00955 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 2 | worker00937_clip017 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 3 | worker00953_clip007 | worker00953 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | quality_stratified_random_v1 | 4 | worker00953_clip015 | worker00953 | 1.0000 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 1 | worker01005_clip015 | worker01005 | 0.8087 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 2 | worker00955_clip017 | worker00955 | 0.6501 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 3 | worker01073_clip008 | worker01073 | 0.7127 | 1.000 | 0.000 | Y |
| episode_001 | 4 | submitted_full_replay_v1 | 4 | worker00930_clip012 | worker00930 | 0.7983 | 0.999 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 1 | worker01073_clip008 | worker01073 | 0.7730 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 2 | worker01005_clip015 | worker01005 | 0.5867 | 1.000 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 3 | worker00930_clip012 | worker00930 | 0.5468 | 0.999 | 0.000 | Y |
| episode_001 | 4 | ts2vec_kcenter_v1 | 4 | worker01021_clip008 | worker01021 | 0.4514 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 1 | worker00955_clip017 | worker00955 | 5.2065 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 2 | worker01005_clip015 | worker01005 | 4.8046 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 3 | worker00953_clip007 | worker00953 | 3.3955 | 1.000 | 0.000 | Y |
| episode_001 | 4 | window_kcenter_v1 | 4 | worker01021_clip008 | worker01021 | 2.3479 | 1.000 | 0.000 | Y |
| episode_002 | 1 | oracle_greedy_target_family_v1 | 1 | worker01063_clip016 | worker01063 | 0.5000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | quality_only_v1 | 1 | worker00907_clip007 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | quality_stratified_random_v1 | 1 | worker00966_clip016 | worker00966 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 1 | submitted_full_replay_v1 | 1 | worker00907_clip016 | worker00907 | 0.9244 | 1.000 | 0.000 | Y |
| episode_002 | 1 | ts2vec_kcenter_v1 | 1 | worker01102_clip004 | worker01102 | 0.7195 | 0.994 | 0.001 | Y |
| episode_002 | 1 | window_kcenter_v1 | 1 | worker01035_clip014 | worker01035 | 5.6128 | 0.977 | 0.005 | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | 1 | worker01063_clip016 | worker01063 | 0.5000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | oracle_greedy_target_family_v1 | 2 | worker00918_clip013 | worker00918 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_only_v1 | 1 | worker00907_clip007 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_only_v1 | 2 | worker00907_clip010 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_stratified_random_v1 | 1 | worker00966_clip016 | worker00966 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | quality_stratified_random_v1 | 2 | worker00966_clip003 | worker00966 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 2 | submitted_full_replay_v1 | 1 | worker00907_clip016 | worker00907 | 0.9244 | 1.000 | 0.000 | Y |
| episode_002 | 2 | submitted_full_replay_v1 | 2 | worker00918_clip004 | worker00918 | 0.8368 | 0.995 | 0.001 | Y |
| episode_002 | 2 | ts2vec_kcenter_v1 | 1 | worker01102_clip004 | worker01102 | 0.7195 | 0.994 | 0.001 | Y |
| episode_002 | 2 | ts2vec_kcenter_v1 | 2 | worker01092_clip002 | worker01092 | 0.7150 | 1.000 | 0.000 | Y |
| episode_002 | 2 | window_kcenter_v1 | 1 | worker01035_clip014 | worker01035 | 5.6128 | 0.977 | 0.005 | Y |
| episode_002 | 2 | window_kcenter_v1 | 2 | worker01063_clip016 | worker01063 | 5.2344 | 1.000 | 0.000 | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | 1 | worker01063_clip016 | worker01063 | 0.5000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | 2 | worker00918_clip013 | worker00918 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | 3 | worker01125_clip015 | worker01125 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | oracle_greedy_target_family_v1 | 4 | worker01125_clip004 | worker01125 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 1 | worker00907_clip007 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 2 | worker00907_clip010 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 3 | worker00907_clip016 | worker00907 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_only_v1 | 4 | worker00918_clip013 | worker00918 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 1 | worker00966_clip016 | worker00966 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 2 | worker00966_clip003 | worker00966 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 3 | worker00918_clip013 | worker00918 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | quality_stratified_random_v1 | 4 | worker01021_clip004 | worker01021 | 1.0000 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 1 | worker00907_clip016 | worker00907 | 0.9244 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 2 | worker00918_clip004 | worker00918 | 0.8368 | 0.995 | 0.001 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 3 | worker01063_clip015 | worker01063 | 0.8297 | 1.000 | 0.000 | Y |
| episode_002 | 4 | submitted_full_replay_v1 | 4 | worker01102_clip004 | worker01102 | 0.6737 | 0.994 | 0.001 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 1 | worker01102_clip004 | worker01102 | 0.7195 | 0.994 | 0.001 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 2 | worker01092_clip002 | worker01092 | 0.7150 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 3 | worker00907_clip010 | worker00907 | 0.6661 | 1.000 | 0.000 | Y |
| episode_002 | 4 | ts2vec_kcenter_v1 | 4 | worker00918_clip004 | worker00918 | 0.6252 | 0.995 | 0.001 | Y |
| episode_002 | 4 | window_kcenter_v1 | 1 | worker01035_clip014 | worker01035 | 5.6128 | 0.977 | 0.005 | Y |
| episode_002 | 4 | window_kcenter_v1 | 2 | worker01063_clip016 | worker01063 | 5.2344 | 1.000 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 3 | worker00907_clip016 | worker00907 | 5.2057 | 1.000 | 0.000 | Y |
| episode_002 | 4 | window_kcenter_v1 | 4 | worker00918_clip004 | worker00918 | 4.5199 | 0.995 | 0.001 | Y |
| episode_003 | 1 | oracle_greedy_target_family_v1 | 1 | worker01010_clip010 | worker01010 | 0.5000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | quality_only_v1 | 1 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | quality_stratified_random_v1 | 1 | worker00953_clip007 | worker00953 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 1 | submitted_full_replay_v1 | 1 | worker01005_clip015 | worker01005 | 0.8087 | 1.000 | 0.000 | Y |
| episode_003 | 1 | ts2vec_kcenter_v1 | 1 | worker01073_clip008 | worker01073 | 0.7730 | 1.000 | 0.000 | Y |
| episode_003 | 1 | window_kcenter_v1 | 1 | worker00955_clip017 | worker00955 | 5.2065 | 1.000 | 0.000 | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | 1 | worker01010_clip010 | worker01010 | 0.5000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | oracle_greedy_target_family_v1 | 2 | worker00937_clip017 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_only_v1 | 1 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_only_v1 | 2 | worker00937_clip002 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_stratified_random_v1 | 1 | worker00953_clip007 | worker00953 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | quality_stratified_random_v1 | 2 | worker00955_clip012 | worker00955 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 2 | submitted_full_replay_v1 | 1 | worker01005_clip015 | worker01005 | 0.8087 | 1.000 | 0.000 | Y |
| episode_003 | 2 | submitted_full_replay_v1 | 2 | worker00955_clip017 | worker00955 | 0.6501 | 1.000 | 0.000 | Y |
| episode_003 | 2 | ts2vec_kcenter_v1 | 1 | worker01073_clip008 | worker01073 | 0.7730 | 1.000 | 0.000 | Y |
| episode_003 | 2 | ts2vec_kcenter_v1 | 2 | worker01005_clip015 | worker01005 | 0.5867 | 1.000 | 0.000 | Y |
| episode_003 | 2 | window_kcenter_v1 | 1 | worker00955_clip017 | worker00955 | 5.2065 | 1.000 | 0.000 | Y |
| episode_003 | 2 | window_kcenter_v1 | 2 | worker01005_clip015 | worker01005 | 4.8046 | 1.000 | 0.000 | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | 1 | worker01010_clip010 | worker01010 | 0.5000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | 2 | worker00937_clip017 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | 3 | worker01073_clip008 | worker01073 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | oracle_greedy_target_family_v1 | 4 | worker01021_clip011 | worker01021 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 1 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 2 | worker00937_clip002 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 3 | worker00937_clip017 | worker00937 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_only_v1 | 4 | worker00953_clip007 | worker00953 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 1 | worker00953_clip007 | worker00953 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 2 | worker00955_clip012 | worker00955 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 3 | worker00955_clip006 | worker00955 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | quality_stratified_random_v1 | 4 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 1 | worker01005_clip015 | worker01005 | 0.8087 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 2 | worker00955_clip017 | worker00955 | 0.6501 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 3 | worker01073_clip008 | worker01073 | 0.7127 | 1.000 | 0.000 | Y |
| episode_003 | 4 | submitted_full_replay_v1 | 4 | worker00930_clip012 | worker00930 | 0.7983 | 0.999 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 1 | worker01073_clip008 | worker01073 | 0.7730 | 1.000 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 2 | worker01005_clip015 | worker01005 | 0.5867 | 1.000 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 3 | worker00930_clip012 | worker00930 | 0.5468 | 0.999 | 0.000 | Y |
| episode_003 | 4 | ts2vec_kcenter_v1 | 4 | worker01021_clip008 | worker01021 | 0.4514 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 1 | worker00955_clip017 | worker00955 | 5.2065 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 2 | worker01005_clip015 | worker01005 | 4.8046 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 3 | worker00953_clip007 | worker00953 | 3.3955 | 1.000 | 0.000 | Y |
| episode_003 | 4 | window_kcenter_v1 | 4 | worker01021_clip008 | worker01021 | 2.3479 | 1.000 | 0.000 | Y |
| episode_004 | 1 | oracle_greedy_target_family_v1 | 1 | worker01021_clip011 | worker01021 | 0.5000 | 1.000 | 0.000 | Y |
| episode_004 | 1 | quality_only_v1 | 1 | worker00928_clip016 | worker00928 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 1 | quality_stratified_random_v1 | 1 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 1 | submitted_full_replay_v1 | 1 | worker00928_clip016 | worker00928 | 0.8285 | 1.000 | 0.000 | Y |
| episode_004 | 1 | ts2vec_kcenter_v1 | 1 | worker00928_clip016 | worker00928 | 1.0307 | 1.000 | 0.000 | Y |
| episode_004 | 1 | window_kcenter_v1 | 1 | worker01021_clip011 | worker01021 | 3.3788 | 1.000 | 0.000 | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | 1 | worker01021_clip011 | worker01021 | 0.5000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | oracle_greedy_target_family_v1 | 2 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | quality_only_v1 | 1 | worker00928_clip016 | worker00928 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | quality_only_v1 | 2 | worker00928_clip019 | worker00928 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | quality_stratified_random_v1 | 1 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | quality_stratified_random_v1 | 2 | worker00966_clip003 | worker00966 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 2 | submitted_full_replay_v1 | 1 | worker00928_clip016 | worker00928 | 0.8285 | 1.000 | 0.000 | Y |
| episode_004 | 2 | submitted_full_replay_v1 | 2 | worker01102_clip004 | worker01102 | 0.7878 | 0.994 | 0.001 | Y |
| episode_004 | 2 | ts2vec_kcenter_v1 | 1 | worker00928_clip016 | worker00928 | 1.0307 | 1.000 | 0.000 | Y |
| episode_004 | 2 | ts2vec_kcenter_v1 | 2 | worker01102_clip004 | worker01102 | 0.7195 | 0.994 | 0.001 | Y |
| episode_004 | 2 | window_kcenter_v1 | 1 | worker01021_clip011 | worker01021 | 3.3788 | 1.000 | 0.000 | Y |
| episode_004 | 2 | window_kcenter_v1 | 2 | worker00928_clip019 | worker00928 | 2.2594 | 1.000 | 0.000 | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | 1 | worker01021_clip011 | worker01021 | 0.5000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | 2 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | 3 | worker01125_clip015 | worker01125 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | oracle_greedy_target_family_v1 | 4 | worker01125_clip004 | worker01125 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_only_v1 | 1 | worker00928_clip016 | worker00928 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_only_v1 | 2 | worker00928_clip019 | worker00928 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_only_v1 | 3 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_only_v1 | 4 | worker00966_clip002 | worker00966 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_stratified_random_v1 | 1 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_stratified_random_v1 | 2 | worker00966_clip003 | worker00966 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_stratified_random_v1 | 3 | worker00966_clip016 | worker00966 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | quality_stratified_random_v1 | 4 | worker01021_clip004 | worker01021 | 1.0000 | 1.000 | 0.000 | Y |
| episode_004 | 4 | submitted_full_replay_v1 | 1 | worker00928_clip016 | worker00928 | 0.8285 | 1.000 | 0.000 | Y |
| episode_004 | 4 | submitted_full_replay_v1 | 2 | worker01102_clip004 | worker01102 | 0.7878 | 0.994 | 0.001 | Y |
| episode_004 | 4 | submitted_full_replay_v1 | 3 | worker01125_clip018 | worker01125 | 0.7915 | 0.948 | 0.010 | Y |
| episode_004 | 4 | submitted_full_replay_v1 | 4 | worker01021_clip011 | worker01021 | 0.8376 | 1.000 | 0.000 | Y |
| episode_004 | 4 | ts2vec_kcenter_v1 | 1 | worker00928_clip016 | worker00928 | 1.0307 | 1.000 | 0.000 | Y |
| episode_004 | 4 | ts2vec_kcenter_v1 | 2 | worker01102_clip004 | worker01102 | 0.7195 | 0.994 | 0.001 | Y |
| episode_004 | 4 | ts2vec_kcenter_v1 | 3 | worker01125_clip004 | worker01125 | 0.6852 | 1.000 | 0.000 | Y |
| episode_004 | 4 | ts2vec_kcenter_v1 | 4 | worker01052_clip017 | worker01052 | 0.5693 | 1.000 | 0.000 | Y |
| episode_004 | 4 | window_kcenter_v1 | 1 | worker01021_clip011 | worker01021 | 3.3788 | 1.000 | 0.000 | Y |
| episode_004 | 4 | window_kcenter_v1 | 2 | worker00928_clip019 | worker00928 | 2.2594 | 1.000 | 0.000 | Y |
| episode_004 | 4 | window_kcenter_v1 | 3 | worker00933_clip014 | worker00933 | 2.2574 | 1.000 | 0.000 | Y |
| episode_004 | 4 | window_kcenter_v1 | 4 | worker01125_clip018 | worker01125 | 2.0051 | 0.948 | 0.010 | Y |
| episode_005 | 1 | oracle_greedy_target_family_v1 | 1 | worker01125_clip015 | worker01125 | 0.5000 | 1.000 | 0.000 | Y |
| episode_005 | 1 | quality_only_v1 | 1 | worker00918_clip013 | worker00918 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 1 | quality_stratified_random_v1 | 1 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 1 | submitted_full_replay_v1 | 1 | worker00989_clip011 | worker00989 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 1 | ts2vec_kcenter_v1 | 1 | worker00989_clip011 | worker00989 | 0.9300 | 1.000 | 0.000 | Y |
| episode_005 | 1 | window_kcenter_v1 | 1 | worker00989_clip011 | worker00989 | 8.4597 | 1.000 | 0.000 | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | 1 | worker01125_clip015 | worker01125 | 0.5000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | oracle_greedy_target_family_v1 | 2 | worker00995_clip019 | worker00995 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | quality_only_v1 | 1 | worker00918_clip013 | worker00918 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | quality_only_v1 | 2 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | quality_stratified_random_v1 | 1 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | quality_stratified_random_v1 | 2 | worker00918_clip013 | worker00918 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | submitted_full_replay_v1 | 1 | worker00989_clip011 | worker00989 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 2 | submitted_full_replay_v1 | 2 | worker01121_clip020 | worker01121 | 0.9689 | 1.000 | 0.000 | Y |
| episode_005 | 2 | ts2vec_kcenter_v1 | 1 | worker00989_clip011 | worker00989 | 0.9300 | 1.000 | 0.000 | Y |
| episode_005 | 2 | ts2vec_kcenter_v1 | 2 | worker01125_clip018 | worker01125 | 0.6651 | 0.948 | 0.010 | Y |
| episode_005 | 2 | window_kcenter_v1 | 1 | worker00989_clip011 | worker00989 | 8.4597 | 1.000 | 0.000 | Y |
| episode_005 | 2 | window_kcenter_v1 | 2 | worker01121_clip020 | worker01121 | 5.1913 | 1.000 | 0.000 | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | 1 | worker01125_clip015 | worker01125 | 0.5000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | 2 | worker00995_clip019 | worker00995 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | 3 | worker01131_clip017 | worker01131 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | oracle_greedy_target_family_v1 | 4 | worker01131_clip011 | worker01131 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_only_v1 | 1 | worker00918_clip013 | worker00918 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_only_v1 | 2 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_only_v1 | 3 | worker00969_clip017 | worker00969 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_only_v1 | 4 | worker00975_clip016 | worker00975 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_stratified_random_v1 | 1 | worker00933_clip014 | worker00933 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_stratified_random_v1 | 2 | worker00918_clip013 | worker00918 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_stratified_random_v1 | 3 | worker00975_clip020 | worker00975 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | quality_stratified_random_v1 | 4 | worker00995_clip019 | worker00995 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | submitted_full_replay_v1 | 1 | worker00989_clip011 | worker00989 | 1.0000 | 1.000 | 0.000 | Y |
| episode_005 | 4 | submitted_full_replay_v1 | 2 | worker01121_clip020 | worker01121 | 0.9689 | 1.000 | 0.000 | Y |
| episode_005 | 4 | submitted_full_replay_v1 | 3 | worker01121_clip017 | worker01121 | 0.9537 | 0.911 | 0.018 | Y |
| episode_005 | 4 | submitted_full_replay_v1 | 4 | worker00918_clip004 | worker00918 | 0.8918 | 0.995 | 0.001 | Y |
| episode_005 | 4 | ts2vec_kcenter_v1 | 1 | worker00989_clip011 | worker00989 | 0.9300 | 1.000 | 0.000 | Y |
| episode_005 | 4 | ts2vec_kcenter_v1 | 2 | worker01125_clip018 | worker01125 | 0.6651 | 0.948 | 0.010 | Y |
| episode_005 | 4 | ts2vec_kcenter_v1 | 3 | worker00918_clip004 | worker00918 | 0.6482 | 0.995 | 0.001 | Y |
| episode_005 | 4 | ts2vec_kcenter_v1 | 4 | worker01121_clip017 | worker01121 | 0.6435 | 0.911 | 0.018 | Y |
| episode_005 | 4 | window_kcenter_v1 | 1 | worker00989_clip011 | worker00989 | 8.4597 | 1.000 | 0.000 | Y |
| episode_005 | 4 | window_kcenter_v1 | 2 | worker01121_clip020 | worker01121 | 5.1913 | 1.000 | 0.000 | Y |
| episode_005 | 4 | window_kcenter_v1 | 3 | worker01004_clip002 | worker01004 | 4.2460 | 1.000 | 0.000 | Y |
| episode_005 | 4 | window_kcenter_v1 | 4 | worker00918_clip001 | worker00918 | 4.1764 | 0.994 | 0.001 | Y |

## Decision Notes

- Primary rows exclude same-feature-family selector/eval comparisons.
- Oracle rows, when present, are diagnostics because they inspect the target set.
- Deployable v1 policies only select candidates that pass quality and artifact gates.
