# Downstream Coverage Supervised Smoke

This is a source-family pseudo-label frozen-feature supervised probe, not real challenge-label downstream proof.

## Decision

- downstream training: `hold_large_training`
- read: source-family pseudo-label bridge downstream benchmark ran with predeclared frozen model heads; keep this as an identifiability gate and do not treat it as real challenge-label downstream proof.
- top policy: `window_kcenter_v1`
- baseline policy: `quality_stratified_random_v1`
- target-family discovery delta vs baseline: `0.000000`
- balanced accuracy delta vs baseline: `-0.027778`
- NLL delta vs baseline: `-1.533673`

## Run

- episodes: `6`
- budgets: `0, 1, 2, 4`
- downstream representations: `window, raw_shape_stats`
- downstream model heads: `nearest_centroid, ridge_classifier`

## Budget Means

| policy | budget | discovery rate | bridge clips | balanced accuracy gain | NLL reduction | after known target frac | rows |
|---|---:|---:|---:|---:|---:|---:|---:|
| oracle_greedy_target_family_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| oracle_greedy_target_family_v1 | 1 | 0.500000 | 1.000000 | 0.222222 | 12.113536 | 0.500000 | 24 |
| oracle_greedy_target_family_v1 | 2 | 1.000000 | 2.000000 | 0.347222 | 23.594782 | 1.000000 | 24 |
| oracle_greedy_target_family_v1 | 4 | 1.000000 | 2.000000 | 0.351852 | 23.549905 | 1.000000 | 24 |
| quality_only_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| quality_only_v1 | 1 | 0.250000 | 0.500000 | 0.004630 | 4.474603 | 0.250000 | 24 |
| quality_only_v1 | 2 | 0.416667 | 1.333333 | 0.087963 | 8.996977 | 0.416667 | 24 |
| quality_only_v1 | 4 | 0.416667 | 2.500000 | 0.141204 | 9.557287 | 0.416667 | 24 |
| quality_stratified_random_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| quality_stratified_random_v1 | 1 | 0.166667 | 0.333333 | 0.013889 | 3.379214 | 0.166667 | 24 |
| quality_stratified_random_v1 | 2 | 0.250000 | 0.666667 | 0.060185 | 5.640255 | 0.250000 | 24 |
| quality_stratified_random_v1 | 4 | 0.666667 | 1.666667 | 0.187500 | 14.974770 | 0.666667 | 24 |
| submitted_full_replay_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| submitted_full_replay_v1 | 1 | 0.333333 | 0.666667 | 0.016204 | 5.963311 | 0.333333 | 24 |
| submitted_full_replay_v1 | 2 | 0.416667 | 1.166667 | 0.020833 | 7.196662 | 0.416667 | 24 |
| submitted_full_replay_v1 | 4 | 0.833333 | 2.166667 | 0.120370 | 15.618887 | 0.833333 | 24 |
| ts2vec_kcenter_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| ts2vec_kcenter_v1 | 1 | 0.166667 | 0.333333 | 0.016204 | 3.078567 | 0.166667 | 24 |
| ts2vec_kcenter_v1 | 2 | 0.250000 | 0.500000 | 0.057870 | 5.317338 | 0.250000 | 24 |
| ts2vec_kcenter_v1 | 4 | 0.583333 | 1.666667 | 0.060185 | 11.031248 | 0.583333 | 24 |
| window_kcenter_v1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 24 |
| window_kcenter_v1 | 1 | 0.166667 | 0.333333 | 0.046296 | 3.564662 | 0.166667 | 24 |
| window_kcenter_v1 | 2 | 0.500000 | 1.000000 | 0.131944 | 10.377028 | 0.500000 | 24 |
| window_kcenter_v1 | 4 | 0.666667 | 1.833333 | 0.159722 | 13.441097 | 0.666667 | 24 |

## Caveat

- Budget `0` is the support-only baseline. Later budgets add selected candidate clips to support before evaluating the pseudo-label probe.
- This checks whether acquisition changes a tiny downstream classifier/probe; it is still not a learned query policy or TS2Vec retraining proof.
